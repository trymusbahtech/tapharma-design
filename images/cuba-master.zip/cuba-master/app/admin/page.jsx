"use client";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";

import ErrorComponent from "@/components/global/ErrorComponent";
import Loader from "@/components/global/Loader";
import Table from "@/components/global/Table";
import AddNewAdmin from "@/components/admin/AddNewAdmin";
import { useState } from "react";

export default function AdminPage() {
    const [page, setPage] = useState(1);
    const BaseUrl = process.env.BASE_URL;

    const getAllAdmins = async ({ queryKey }) => {
        const [_, page] = queryKey
        const { data } = await axios.get(`${BaseUrl}/all-admins?page=${page}`)
        return data
    }
    const { data, isLoading, isError } = useQuery(['getAllAdmins', page], getAllAdmins);

    if (isLoading) return (<Loader />)
    if (isError) return (<ErrorComponent />)
    return (
        <>
            <div className="flex items-center justify-between flex-col lg:flex-row gap-1.5">
                <h3 className="text-xl lg:text-3xl text-slate-500">
                    {data?.message}
                </h3>
                <AddNewAdmin />
            </div>
            <Table data={data?.data} page={page} setPage={setPage} pagination={data?.data?.meta} />
        </>
    )
}