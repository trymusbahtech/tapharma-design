"use client";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

import axios from "axios";
import Input from "@/components/global/Input";

import { GoogleMap, Marker, useJsApiLoader } from '@react-google-maps/api';

import { postData } from "@/utils/DataFetching";
import { toast } from "react-toastify";

import Loader from "@/components/global/Loader";
import ErrorComponent from "@/components/global/ErrorComponent";

import { LuLanguages } from "react-icons/lu";
import { MdAddLink, MdOutlinePrivacyTip } from "react-icons/md";
import { TfiLocationPin, } from "react-icons/tfi";
import { useCallback } from "react";


const schema = yup.object({
  main_image: yup.mixed().required("يجب رفع صورة الملعب").test(value => {
    return value?.length !== 0 ? value.length : true;
  }),
  ar_title: yup.string().required("برجاء ادخال الأسم بالعربية"),
  en_title: yup.string().required("برجاء ادخال الأسم بالإنجليزية"),
  ar_short_desc: yup.string().required("برجاء ادخال نص تعريفي"),
  en_short_desc: yup.string().required("برجاء ادخال نص تعريفي"),
  type: yup.string().required("برجاء ادخال النوع"),
  ar_desc: yup.string().required("برجاء ادخال الوصف"),
  en_desc: yup.string().required("برجاء ادخال الوصف"),
  address: yup.string().required("برجاء ادخال العنوان"),
  from_time: yup.string().required("برجاء ادخال وقت البداية"),
  to_time: yup.string().required("برجاء ادخال وقت النهاية"),
  category_id: yup.string().required("برجاء ادخال التصنيف"),
  latitude: yup.string().required(""),
  longitude: yup.string().required(""),
});

const AddNewPlayground = () => {
  let DefaultLocation = { lat: 24.579894878856198, lng: 46.61839441371633 }
  const [defaultLocation, setDefaultLocation] = useState(DefaultLocation);
  const [map, setMap] = useState(null)
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: process.env.GOOGLE_API_KEY
  })

  const onLoad = useCallback(function callback(map) {
    // This is just an example of getting and using the map instance!!! don't just blindly copy!
    const bounds = new window.google.maps.LatLngBounds(DefaultLocation);
    map.fitBounds(bounds);

    setMap(map)
  }, [])

  const onUnmount = useCallback(function callback(map) {
    setMap(null)
  }, [])

  const [attachmentsList, setAttachmentsList] = useState([]);
  const [attachmentsArray, setAttachmentsArray] = useState([]);
  const [faciletiesList, setfaciletiesList] = useState([]);
  const [facilitiesArray, setfaciletiesArray] = useState([]);
  const [facilitiesTitleArray, setFacilitiesTitleArray] = useState([]);
  const [facilitiesDescArray, setFacilitiesDescArray] = useState([]);
  const handleAttchmentsChange = (e) => {
    if (e.target.files) {
      setAttachmentsArray([...attachmentsArray, e.target.files[0]]);
    }
  }
  const handleFacilitiesChange = (e) => {
    if (e.target.files) {
      setfaciletiesArray([...facilitiesArray, e.target.files[0]]);
    }
  }
  const handleFacilitiesTitleChange = (e) => {
    if (e.target.value) {
      setFacilitiesTitleArray([...facilitiesTitleArray, e.target.value]);
    }
  }
  const handleFacilitiesDescChange = (e) => {
    if (e.target.value) {
      setFacilitiesDescArray([...facilitiesDescArray, e.target.value]);
    }
  }

  function handleChangeLocation(e) {
    setDefaultLocation({ lat: e.latLng.lat(), lng: e.latLng.lng() });
    reset({
      latitude: e.latLng.lat(), longitude: e.latLng.lng()
    })
  }

  const BaseUrl = process.env.BASE_URL;
  const getallCategories = async ({ queryKey }) => {
    const { data } = await axios.get(`${BaseUrl}/allCategories`)
    return data
  }
  const { data: FakeData, isLoading, isError } = useQuery(['getallCategories'], getallCategories);

  const addNewPlaygroundMutation = useMutation({
    mutationFn: (data) => {
      var formdata = new FormData();
      formdata.append('ar_title', data.ar_title);
      formdata.append('en_title', data.en_title);
      formdata.append('ar_short_desc', data.ar_short_desc);
      formdata.append('en_short_desc', data.en_short_desc);
      formdata.append('type', data.type);
      formdata.append('ar_desc', data.ar_desc);
      formdata.append('en_desc', data.en_desc);
      formdata.append('address', data.address);
      formdata.append('from_time', data.from_time);
      formdata.append('to_time', data.to_time);
      formdata.append('category_id', data.category_id);
      formdata.append('latitude', data.latitude);
      formdata.append('longitude', data.longitude);
      data.main_image ? formdata.append('main_image', data.main_image[0] && data.main_image[0], data.main_image[0] && data.main_image[0].name) : "";
      for (var x = 0; x < attachmentsArray.length; x++) {
        formdata.append(`attachments[${x}]`, attachmentsArray[x], attachmentsArray[x].name)
      }
      for (var x = 0; x < facilitiesArray.length; x++) {
        formdata.append(`facilities[${x}][image]`, facilitiesArray[x], facilitiesArray[x].name);
        formdata.append(`facilities[${x}][title]`, facilitiesTitleArray[x]);
        formdata.append(`facilities[${x}][desc]`, facilitiesDescArray[x]);
      }

      return postData('/store-playground', formdata)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
      }
      else {
        toast.success('تم إضافة الملعب بنجاح', {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        });
        reset({
          main_image: "", ar_title: "", en_title: "", ar_short_desc: "",
          en_short_desc: "", type: "", ar_desc: "", en_desc: "",
          address: "", from_time: "", to_time: "",
          attachments: [], category_id: "", facilities: [], latitude: "", longitude: "",
        });
        setDefaultLocation({ lat: 24.57932360407722, lng: 47.004235101996166 })
        setAttachmentsList([])
        setfaciletiesList([])
      }
    },
    onError: () => {
      // console.log(Error);
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "light",
      });
    }
  })

  useEffect(() => {
    setTimeout(() => {
      reset({
        main_image: "", ar_title: "", en_title: "", ar_short_desc: "",
        en_short_desc: "", type: "", ar_desc: "", en_desc: "",
        address: "", from_time: "", to_time: "",
        attachments: [], category_id: "", facilities: [], latitude: "", longitude: "",
      });
      setDefaultLocation({ lat: 24.57932360407722, lng: 47.004235101996166 })
    }, 2000);
  }, []);

  const {
    handleSubmit,
    register,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const formSubmit = (data) => {
    addNewPlaygroundMutation.mutate(data);
  };

  const onAddBtnClick = event => {
    setAttachmentsList(attachmentsList.concat(
      <div key={attachmentsList.length} className="flex items-center gap-2">
        <span className="text-base text-slate-400">{attachmentsList.length + 1}-</span>
        <div>
          <input type="file" className="file-input file-input-bordered file-input-primary w-full max-w-xs" onChange={handleAttchmentsChange} dir="ltr" />
        </div>
      </div>
    ));
  };

  const onAddfaciletiesListClick = event => {
    setfaciletiesList(faciletiesList.concat(
      <div key={faciletiesList.length} className="flex items-start md:items-center gap-2">
        <span className="text-base text-slate-400">{faciletiesList.length + 1}-</span>
        <div className="flex items-end gap-2 flex-col md:flex-row">
          <input type="file" className="file-input file-input-bordered file-input-primary w-full max-w-xs" onChange={handleFacilitiesChange} dir="ltr" />
          <div>
            <label className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">إسم الإضافة</label>
            <div className={`relative transition-all duration-300`}>
              <input
                type="text"
                className="text-sm placeholder-gray-500 pl-10 pr-4 rounded-lg border border-gray-400 w-full py-3 focus:outline-none focus:border-blue-400"
                placeholder='إسم الإضافة'
                onChange={handleFacilitiesTitleChange}
              />
            </div>
          </div>
          <div>
            <label className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">وصف الإضافة</label>
            <div className={`relative transition-all duration-300`}>
              <input
                type="text"
                className="text-sm placeholder-gray-500 pl-10 pr-4 rounded-lg border border-gray-400 w-full py-3 focus:outline-none focus:border-blue-400"
                placeholder='وصف الإضافة'
                onChange={handleFacilitiesDescChange}
              />
            </div>
          </div>
        </div>
      </div>
    ));
  };

  if (isLoading) return (<Loader />)
  if (isError) return (<ErrorComponent />)
  return (
    <>
      <h3 className="text-slate-800 text-lg lg:text-3xl font-semibold px-10 lg:px-0">
        إضافة ملعب جديد
      </h3>
      <div className="container mx-auto mt-10 flex flex-col justify-between bg-white p-5 rounded-xl">
        <form onSubmit={handleSubmit(formSubmit)}>
          <div className="flex gap-2 flex-wrap my-10">
            <h3 className="w-full text-green-600 text-2xl mb-3">
              الإعدادت الإفتراضية
            </h3>
            <Input
              className="grow"
              id="ar_title"
              label="الأسم بالعربية"
              placeholder="الأسم بالعربية"
              type="text"
              name="ar_title"
              icon={<LuLanguages />}
              register={{ ...register("ar_title") }}
              errorMessage={errors?.ar_title?.message}
            />
            <Input
              className="grow"
              id="en_title"
              label="الأسم بالإنجليزية"
              placeholder="الأسم بالإنجليزية"
              type="text"
              name="en_title"
              icon={<LuLanguages />}
              register={{ ...register("en_title") }}
              errorMessage={errors?.en_title?.message}
            />
            {/* <Input
              id="type"
              label="النوع (small,large)"
              placeholder="النوع"
              type="text"
              name="type"
              icon={<MdOutlinePrivacyTip />}
              register={{ ...register("type") }}
              errorMessage={errors?.type?.message}
            /> */}
            <div className="flex flex-col relative grow">
              <label className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">
                <span className="label-text">إختيار النوع</span>
              </label>
              <select {...register("type")} className="select select-bordered w-full">
                <option disabled selected>إختيار نوع الملعب</option>
                <option value="large">ملعب كبير</option>
                <option value="small">ملعب صغير</option>
              </select>
              <span className="absolute -bottom-1 right-0 w-full  text-xs text-red-700 ">
                {errors?.type?.message}
              </span>
            </div>
            <Input
              className="grow"
              id="ar_short_desc"
              label="نص تعريفي قصير"
              placeholder="نص تعريفي قصير"
              type="text"
              name="ar_short_desc"
              register={{ ...register("ar_short_desc") }}
              errorMessage={errors?.ar_short_desc?.message}
            />
            <Input
              className="grow"
              id="en_short_desc"
              label="نص تعريفي قصير بالإنجليزية"
              placeholder="نص تعريفي قصير بالإنجليزية"
              type="text"
              name="en_short_desc"
              register={{ ...register("en_short_desc") }}
              errorMessage={errors?.en_short_desc?.message}
            />
            <div className="flex flex-col relative">
              <span className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">صورة الملعب</span>
              <input type="file" className="file-input file-input-bordered file-input-primary w-full max-w-xs" {...register("main_image")} dir="ltr" />
              <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                {errors?.main_image?.message}
              </span>
            </div>
            <div className="w-full flex flex-wrap gap-5 mt-2">
              <div className="flex flex-col relative flex-1">
                <label htmlFor="ar_desc" className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">
                  نص تعريفي
                </label>
                <textarea name="ar_desc" id="ar_desc" cols="30" className="border border-slate-400 rounded-lg p-3 bg-white" rows="10"{...register("ar_desc")}>
                  نص تعريفي
                </textarea>
                <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                  {errors?.ar_desc?.message}
                </span>
              </div>
              <div className="flex flex-col relative flex-1">
                <label htmlFor="ar_desc" className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">
                  نص تعريفي بالإنجليزية
                </label>
                <textarea name="en_desc" id="en_desc" cols="30" className="border border-slate-400 rounded-lg p-3 bg-white" rows="10"{...register("en_desc")}>
                  نص تعريفي بالإنجليزية
                </textarea>
                <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                  {errors?.en_desc?.message}
                </span>
              </div>
            </div>
          </div>

          <div className="flex gap-2 flex-wrap my-10">
            <h3 className="w-full text-green-600 text-2xl mb-3">
              إعدادات الموقع
            </h3>
            <Input
              className="grow"
              id="address"
              label="العنوان "
              placeholder="العنوان "
              type="text"
              name="address"
              icon={<TfiLocationPin />}
              register={{ ...register("address") }}
              errorMessage={errors?.address?.message}
            />
            <Input
              className="grow"
              id="latitude"
              label="latitude"
              placeholder="latitude"
              type="text"
              name="latitude"
              icon={<TfiLocationPin />}
              register={{ ...register("latitude") }}
              errorMessage={errors?.latitude?.message}
            />
            <Input
              className="grow"
              id="longitude"
              label="longitude"
              placeholder="longitude"
              type="text"
              name="longitude"
              icon={<TfiLocationPin />}
              register={{ ...register("longitude") }}
              errorMessage={errors?.longitude?.message}
            />
            {
              isLoaded &&
              <GoogleMap
                mapContainerStyle={{ width: "100%", height: "350px" }}
                center={defaultLocation}
                zoom={5}
                onLoad={onLoad}
                onUnmount={onUnmount}
                onClick={handleChangeLocation}
              >
                <Marker
                  position={defaultLocation} />
              </GoogleMap>
            }
          </div>

          <div className="flex gap-10 flex-wrap my-10">
            <h3 className="w-full text-green-600 text-2xl mb-3">
              إعداد توقيت الملعب
            </h3>
            <div className="flex flex-col relative">
              <span className="mb-3 inline-block text-xs sm:text-sm tracking-wide text-slate-600">وقت البداية</span>
              {/* <TimePicker onChange={onChange} value={value} /> */}
              <input type="time" {...register('from_time')} className="border border-slate-400 rounded-lg p-3" />
              <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                {errors?.from_time?.message}
              </span>
            </div>
            <div className="flex flex-col relative">
              <span className="mb-3 inline-block text-xs sm:text-sm tracking-wide text-slate-600">وقت النهاية</span>
              {/* <TimePicker onChange={onChangeTo} value={toValue} /> */}
              <input type="time" {...register('to_time')} className="border border-slate-400 rounded-lg p-3" />
              <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                {errors?.to_time?.message}
              </span>
            </div>

            <div className="w-[calc(50%-12px)] relative grow">
              <label className="label">
                <span className="label-text">إختيار القسم</span>
              </label>
              <select {...register("category_id")} className="select select-bordered w-full">
                <option disabled defaultValue>إختيار القسم</option>
                {FakeData?.data?.map(singleCat => (
                  <option value={singleCat.id}>{singleCat.ar_title}</option>
                ))}
              </select>
              <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                {errors?.category_id?.message}
              </span>
            </div>
          </div>

          <div className="flex gap-2 flex-wrap my-10">
            <div className="w-full text-green-600 text-2xl mb-3 flex items-center gap-4">
              المرفقات الخاصة بالملعب
              <button type="button" onClick={onAddBtnClick} className="w-10 h-10 text-2xl text-slate-50 bg-green-500 flex items-center justify-center rounded-full">
                <MdAddLink />
              </button>
            </div>
            <div className="flex items-center gap-3 flex-wrap">
              {attachmentsList}
            </div>
          </div>

          <div className="flex gap-2 flex-wrap my-10">
            <div className="w-full text-green-600 text-2xl mb-3 flex items-center gap-4">
              الإضافات الخاصة بالملعب
              <button type="button" onClick={onAddfaciletiesListClick} className="w-10 h-10 text-2xl text-slate-50 bg-green-500 flex items-center justify-center rounded-full">
                <MdAddLink />
              </button>
            </div>
            <div className="flex items-center gap-3 flex-wrap">
              {faciletiesList}
            </div>
          </div>

          <button
            disabled={addNewPlaygroundMutation.isLoading}
            className="flex items-center justify-center focus:outline-none text-white text-sm sm:text-base bg-[#198754] hover:bg-[#198754bc] rounded py-2 transition duration-150 ease-in float-left w-52"
            type="submit"
          >
            حفظ التعديلات
            {
              addNewPlaygroundMutation.isLoading &&
              <div role="status">
                <svg aria-hidden="true" className="w-6 h-6 mr-2 text-slate-50 animate-spin fill-[#106000]" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor" />
                  <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill" />
                </svg>
                <span className="sr-only"></span>
              </div>
            }
          </button>
        </form>
      </div>
    </>
  )
}

export default AddNewPlayground