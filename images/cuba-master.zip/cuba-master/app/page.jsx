'use client'
import ErrorComponent from "@/components/global/ErrorComponent";
import Loader from "@/components/global/Loader";
import BottomArea from "@/components/home/BottomArea";
import TopArea from "@/components/home/TopArea";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";


export default function Home() {
  const BaseUrl = process.env.BASE_URL;
  const getAllUsers = async ({ queryKey }) => {
    const [_, page] = queryKey
    const { data } = await axios.get(`${BaseUrl}/home-statistics`)
    return data
  }
  const { data, isLoading, isError } = useQuery(['getAllUsers', 1], getAllUsers);

  if (isLoading) return (<Loader />)
  if (isError) return (<ErrorComponent />)
  return (
    <>
      <TopArea playgroundMoney={data?.data?.playgrounds_money_of_playgrounds_reservations} reservation={data?.data?.reservations_count} playgroundCount={data?.data?.playgrounds_count} />
      <BottomArea orders={data?.data?.playground_orders_count_desc} price={data?.data?.playgrounds_with_total_price} users={data?.data?.users_with_count_of_orders} />
    </>
  )
}
