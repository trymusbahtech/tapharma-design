'use client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

import axios from 'axios';
import { useState } from 'react';

import ErrorComponent from '@/components/global/ErrorComponent';
import Loader from '@/components/global/Loader';
import Pagination from '@/components/global/Pagination';
import Swal from 'sweetalert2';
import { toast } from 'react-toastify';
import { postData } from '@/utils/DataFetching';

const Requestes = () => {
  const [selectedFilter, setSelectedFilter] = useState("ALL");
  const [page, setPage] = useState(1);
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");

  const BaseUrl = process.env.BASE_URL;
  const getOrders = async ({ queryKey }) => {
    const [_, filter, page, search] = queryKey
    var formdata = new FormData();
    formdata.append("status", filter);
    const { data } = await axios.post(`${BaseUrl}/all-orders?page=${page}&search=${search}`, formdata)
    return data
  }
  const { data, isLoading, isError } = useQuery(['getOrders', selectedFilter, page, search], getOrders);

  const acceptOrder = (id) => {
    Swal.fire({
      title: 'هل انت متأكد من قبول هذا الطلب?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#147700',
      cancelButtonColor: '#d33',
      confirmButtonText: 'قبول',
      cancelButtonText: 'إلغاء'
    }).then((result) => {
      if (result.isConfirmed) {
        acceptOrderMutation.mutate(id);
      }
    })
  }

  const acceptOrderMutation = useMutation({
    mutationFn: (id) => {
      var formdata = new FormData();
      formdata.append("order_id", id);
      return postData('/accept-order', formdata)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
      }
      else {
        toast.success(data.message, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "dark",
        });
      }
      queryClient.invalidateQueries(["getOrders"])
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "dark",
      });
    }
  })

  const removeFine = (id) => {
    Swal.fire({
      title: 'هل انت متأكد من حذف غرامة الطلب?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#147700',
      cancelButtonColor: '#d33',
      confirmButtonText: 'قبول',
      cancelButtonText: 'إلغاء'
    }).then((result) => {
      if (result.isConfirmed) {
        removeFineMutation.mutate(id);
      }
    })
  }

  const removeFineMutation = useMutation({
    mutationFn: (id) => {
      var formdata = new FormData();
      formdata.append("order_id", id);
      return postData('/remove-order-fine', formdata)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
      }
      else {
        toast.success(data.message, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "dark",
        });
      }
      queryClient.invalidateQueries(["getOrders"])
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "dark",
      });
    }
  })

  const finishOrder = (id) => {
    Swal.fire({
      title: 'هل انت متأكد من إنهاء هذا الطلب?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#147700',
      cancelButtonColor: '#d33',
      confirmButtonText: 'قبول',
      cancelButtonText: 'إلغاء'
    }).then((result) => {
      if (result.isConfirmed) {
        finishOrderMutation.mutate(id);
      }
    })
  }

  const finishOrderMutation = useMutation({
    mutationFn: (id) => {
      var formdata = new FormData();
      formdata.append("order_id", id);
      return postData('/finish-order', formdata)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
      }
      else {
        toast.success(data.message, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "dark",
        });
      }
      queryClient.invalidateQueries(["getOrders"])
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "dark",
      });
    }
  })

  const endOrderWithFine = (id) => {
    Swal.fire({
      title: 'هل انت متأكد من إلغاء هذا الطلب?',
      icon: 'warning',
      showCancelButton: true,
      showDenyButton: true,
      confirmButtonColor: '#147700',
      denyButtonColor: '#a0a0a0',
      cancelButtonColor: '#d33',
      confirmButtonText: 'إلغاء بدون غرامة',
      denyButtonText: 'إلغاء مع غرامة',
      cancelButtonText: 'تراجع'
    }).then((result) => {
      if (result.isConfirmed) {
        let data = {
          id: id,
          fine: "no"
        }
        endOrderWithFineMutation.mutate(data);
      }
      if (result.isDenied) {
        let data = {
          id: id,
          fine: "yes"
        }
        endOrderWithFineMutation.mutate(data);
      }
    })
  }

  const endOrderWithFineMutation = useMutation({
    mutationFn: (data) => {
      var formdata = new FormData();
      formdata.append("order_id", data?.id);
      formdata.append("make_fine", data?.fine);
      return postData('/cancelOrderWithMakeFine', formdata)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
      }
      else {
        toast.success(data.message, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "dark",
        });
      }
      queryClient.invalidateQueries(["getOrders"])
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "dark",
      });
    }
  })

  if (isError) return (<ErrorComponent />)
  return (
    <>
      <div className="flex items-center justify-between flex-col lg:flex-row gap-1.5">
        <div className="text-xl text-slate-950">
          طلبات الحجز
        </div>
        <select className="select select-bordered w-full max-w-xs" onChange={(e) => setSelectedFilter(e.target.value)}>
          <option value="ALL" selected={selectedFilter === "ALL" && true}>جميع الطلبات</option>
          <option value="ORDER_NEED_Admin_ACCEPT" selected={selectedFilter === "ORDER_NEED_Admin_ACCEPT" && true}>طلبات تحتاج لموافقة الأدمن</option>
          <option value="ORDER_USER_CANCELLED" selected={selectedFilter === "ORDER_USER_CANCELLED" && true}>طلبات ملغية من جانب المستخدم</option>
          <option value="ORDER_ADMIN_CANCELLED" selected={selectedFilter === "ORDER_ADMIN_CANCELLED" && true}>طلبات ملغية من جانب الأدمن</option>
          <option value="ORDER_NEED_PAYMENT" selected={selectedFilter === "ORDER_NEED_PAYMENT" && true}>طلبات تحتاج للدفع</option>
          <option value="ORDER_ACCEPTED" selected={selectedFilter === "ORDER_ACCEPTED" && true}>الطلبات المقبولة</option>
          <option value="ORDER_FINISHED" selected={selectedFilter === "ORDER_FINISHED" && true}>طلبات منتهية</option>
          <option value="ORDER_HAS_FINE" selected={selectedFilter === "ORDER_HAS_FINE" && true}>طلبات عليها غرامة</option>
          <option value="ORDER_FINE_FINISHED" selected={selectedFilter === "ORDER_FINE_FINISHED" && true}>طلبات غرامتها مغلقة</option>
        </select>
        <input type="text" className="px-2.5 py-1.5 bg-transparent border border-slate-500 rounded-lg" onChange={(e) => setSearch(e.target.value)} value={search} placeholder="البحث عن مستخدم" />
      </div>
      {
        isLoading ?
          <Loader />
          :
          <section className="container mx-auto mt-10 flex flex-col justify-between">
            <div className="-my-2 overflow-x-auto">
              <div className="inline-block min-w-full align-middle">
                <div className="border rounded-lg p-2.5 lg:p-5 min-h-[250px] lg:min-h-[550px]">
                  <h4 className='text-slate-800 text-lg my-2 px-5'>{data?.message}</h4>
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500">
                          بيانات المستخدم
                        </th>
                        <th scope="col" className="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500">
                          بيانات الملعب
                        </th>
                        <th scope="col" className="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500">
                          التوقيت
                        </th>
                        <th scope="col" className="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500">
                          <span className="">الحالة</span>
                        </th>
                        <th scope="col" className="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500">
                          <span className="">الإجراء</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {data?.data?.data?.map(((item, index) => (
                        <tr key={item?.id}>
                          {/* The Phone OF EACH ELEMENT  */}
                          <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap text-right flex flex-col gap-2">
                            <div className="flex items-center gap-x-2">
                              <img className="object-cover w-8 h-8 rounded-full" src={`${item?.user?.logo ? item?.user?.logo : "/3d-fluency-administrator.png"}`} alt="user-image" />
                              <div className='text-center'>
                                <h2 className="text-xs font-medium text-gray-800 ">{item?.user?.name}</h2>
                                <span dir='ltr'>
                                  <a href={`https://wa.me/${item?.user?.phone_code + item?.user?.phone}`} target='_blank' className="text-sm font-medium text-blue-800">{item?.user?.phone_code}{item?.user?.phone}</a>
                                </span>
                              </div>
                            </div>

                          </td>
                          {/* The Phone OF EACH ELEMENT  */}

                          <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">
                            <div className="flex items-center gap-x-2">
                              <img className="object-cover w-8 h-8 rounded-full" src={`${item?.playground?.main_image ? item?.playground?.main_image : "/3d-fluency-administrator.png"}`} alt="user-image" />
                              <div>
                                <h2 className="text-xs font-medium text-gray-800 ">{item?.playground?.title}</h2>
                                <p className="text-xs font-normal text-gray-600 ">{item?.playground?.category?.title}</p>
                              </div>
                            </div>
                          </td>

                          <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">
                            <div>
                              <h2 className="text-xs font-medium text-gray-800 ">{item?.date}</h2>
                              <p className="text-xs font-normal text-gray-600 ">{item?.from_time} حتي {item?.to_time}</p>
                            </div>
                          </td>

                          {/* The Status OF EACH ELEMENT  */}
                          <td className="px-4 py-4 text-xs font-medium text-gray-700 whitespace-nowrap">
                            <div
                              className={`inline-flex items-center px-3 py-1 rounded-full gap-x-2 text-emerald-500 bg-emerald-100/60`}>
                              <h2 className="text-[10px] font-normal">{
                                item?.status === "need_admin_accept" ?
                                  "يحتاج إلي موافقة الأدمن"
                                  :
                                  item?.status === "has_fine" ?
                                    "عليه غرامة"
                                    :
                                    item?.status === "need_online_payment" ?
                                      "في انتظار الدفع"
                                      :
                                      item?.status === "user_cancelled" ?
                                        "ملغية من قبل المستخدم"
                                        :
                                        item?.status === "admin_cancelled" ?
                                          "ملغية من قبل الأدمن"
                                          :
                                          item?.status === "accepted" ?
                                            "مقبول"
                                            :
                                            item?.status === "finished" ?
                                              "منتهي"
                                              :
                                              item?.status === "has_fine" ?
                                                "لديه غرامة"
                                                :
                                                item?.status === "fine_finished" ?
                                                  "غرامة منتهية"
                                                  :
                                                  ""
                              }</h2>
                            </div>
                          </td>
                          {/* The Status OF EACH ELEMENT  */}

                          <td className="px-2 py-2 text-xs whitespace-nowrap">
                            <div className="dropdown dropdown-right lg:dropdown-bottom">
                              <label tabIndex={item?.id} className="btn m-1">
                                الإجرائات
                              </label>
                              <ul tabIndex={item?.id} className="dropdown-content z-[10] menu p-2 shadow bg-base-100 rounded-box w-52">
                                <li onClick={() => acceptOrder(item?.id)}>
                                  <span>قبول الطلب</span>
                                </li>
                                <li onClick={() => finishOrder(item?.id)}>
                                  <span>إنهاء الطلب</span>
                                </li>
                                <li onClick={() => endOrderWithFine(item?.id)}>
                                  <span>إلغاء الطلب</span>
                                </li>
                                {
                                  item?.status === "has_fine" &&
                                  <li onClick={() => removeFine(item?.id)}>
                                    <span>إلغاء الغرامة</span>
                                  </li>
                                }
                              </ul>
                            </div>
                          </td>
                        </tr>
                      )))}

                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <Pagination pagination={data?.data?.meta} page={page} setPage={setPage} />
          </section>
      }
    </>
  )
}

export default Requestes