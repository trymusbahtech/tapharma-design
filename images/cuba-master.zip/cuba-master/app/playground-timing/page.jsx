'use client';
import React, { useState } from "react";
import Datepicker from "react-tailwindcss-datepicker";

import ErrorComponent from "@/components/global/ErrorComponent";
import Loader from "@/components/global/Loader";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import axios from "axios";
import { toast } from "react-toastify";
import Swal from "sweetalert2";

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";


import { MdDeleteForever } from "react-icons/md";
import { postData } from "@/utils/DataFetching";
import AddNewReserve from "@/components/AddNewReserve";
import ShowNewReserve from "@/components/ShowNewReserve";



const schema = yup.object({
  playground_id: yup.string().required("برجاء إختيار الملعب"),
  dates: yup.array(
    {
      date: yup.string().required("برجاء اختيار اليوم"),
      times: yup.array({
        from_time: yup.string().required("برجاء اختيار وقت البداية"),
        to_time: yup.string().required("برجاء اختيار وقت النهاية")
      }
      ),
    }
  )
});

const PlaygroundTiming = () => {
  const [page, setPage] = useState(1);
  const [selectedTime, setSelectedTime] = useState(415);
  const [numberOfDays, setNumberOfDays] = useState(1);
  const [selectedPlayground, setSelectedPlayground] = useState();
  const [days, setDays] = useState(5);
  const [playgroundTimingList, setPlaygroundTimingList] = useState([]);
  const [startTimes, setStartTimes] = useState([])
  const [endTimes, setEndTimes] = useState([])
  const [timesValue, setTimesValue] = useState([])
  const [playgroundData, setplaygroundData] = useState()
  const [value, setValue] = useState({
    startDate: null,
    endDate: null
  });

  const config = {
    headers: {
      'lang': `ar`,
    }
  }

  const date = new Date();

  // Extract year, month, and day
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based, so add 1
  const day = String(date.getDate()).padStart(2, '0'); // Pad single digits with leading zero

  // Format the date as YYYY-MM-DD
  let currentDate = `${year}-${month}-${day}`;

  const queryClient = useQueryClient();

  const handleStartTime = (e) => {
    if (e.target.value) {
      setStartTimes([...startTimes, e.target.value])
    }
  }

  const handleEndTime = (e) => {
    if (e.target.value) {
      setEndTimes([...endTimes, e.target.value])
    }
  }
  const handleValueOfTime = (e) => {
    if (e.target.value) {
      setTimesValue([...timesValue, e.target.value])
    }
  }

  const handleValueChange = (newValue) => {
    // console.log("newValue:", newValue);
    setValue(newValue);
    reset({ date: newValue.startDate })
  }

  const BaseUrl = process.env.BASE_URL;
  const getAllPlaygrounds = async ({ queryKey }) => {
    const [_, page] = queryKey
    const { data } = await axios.get(`${BaseUrl}/all-playgrounds?page=${page}`)
    return data
  }
  const { data, isLoading, isError } = useQuery(['getAllPlaygrounds', page], getAllPlaygrounds);

  const getAllPlaygroundsDates = async ({ queryKey }) => {
    const [_, config, page, days] = queryKey
    const { data } = await axios.get(`${BaseUrl}/table-of-days?day=${currentDate}&number_of_days=${days}`, config)
    return data
  }
  const { data: PlaygroundTimes, isLoading: timesLoading, isError: timesError } = useQuery(['getAllPlaygroundsDates', config, page, days], getAllPlaygroundsDates);

  // console.log(selectedTime);
  const getOrderDetails = async ({ queryKey }) => {
    const [_, page, selectedTime, config] = queryKey
    const { data } = await axios.get(`${BaseUrl}/get-order-with-time-new?playground_time_id=${selectedTime?.id}&date=${selectedTime?.date}`, config)
    return data
  }
  const { data: orderDetails, isLoading: orderDetailsLoading, isError: orderDetailsError } = useQuery(['getOrderDetails', page, selectedTime, config], getOrderDetails);

  const deleteSingleReservation = (date) => {
    Swal.fire({
      title: 'هل انت متأكد من حذف هذا اليوم بالكامل?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#147700',
      cancelButtonColor: '#d33',
      confirmButtonText: 'حذف',
      cancelButtonText: 'إلغاء'
    }).then((result) => {
      if (result.isConfirmed) {
        deleteSingleReservationMutation.mutate(date);
      }
    })
  }

  const deleteSingleReservationMutation = useMutation({
    mutationFn: (date) => {
      var formdata = new FormData();
      formdata.append("playground_id", date?.theData?.playGroundId);
      formdata.append("date", date?.theData?.theDate?.date);
      return postData('/delete-playground-time-date', formdata)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
      }
      else {
        toast.success(data.message, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "dark",
        });
      }
      queryClient.invalidateQueries(["getAllPlaygroundsDates"])
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "dark",
      });
    }
  })

  const addNewTiming = useMutation({
    mutationFn: (myData) => {
      var myHeaders = new Headers();
      myHeaders.append("Content-Type", "application/json");

      // loop to make dates array 
      const startingDay = new Date(myData?.date);
      var daysArray = []
      for (var i = 0; i < numberOfDays; i++) {
        let thisDay = new Date(startingDay);
        thisDay.setDate(startingDay.getDate() + i);
        daysArray.push(formatDate(thisDay));
      }
      function formatDate(date) {
        var d = new Date(date),
          month = '' + (d.getMonth() + 1),
          day = '' + d.getDate(),
          year = d.getFullYear();

        if (month.length < 2)
          month = '0' + month;
        if (day.length < 2)
          day = '0' + day;

        return [year, month, day].join('-');
      }
      // loop to make dates array 

      // make times loop 
      let myTimes = startTimes?.map((startTime, index) => {
        return ({
          "from_time": startTime,
          "to_time": endTimes[index],
          "value": timesValue[index],
          "value_1": 0,
          "value_2": 0,
          "min_for_value": 0,
          "min_for_value_1": 0,
          "min_for_value_2": 0,
          "is_active": "active"
        })
      }
      )
      // make times loop 

      var timingData =
        JSON.stringify({
          "playground_id": myData?.playground_id,
          "dates":
            daysArray.map(day => (
              {
                "date": day,
                "times": myTimes
              }
            ))
        })

      return postData('/add-timing-to-playground', timingData, myHeaders)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
      }
      else {
        toast.success(data.message, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "dark",
        });
      }
      setPlaygroundTimingList([])
      setStartTimes([])
      setEndTimes([])
      setTimesValue([])
      setValue({
        startDate: null,
        endDate: null
      })
      document.getElementById("closePlayCenterForm").click()
      queryClient.invalidateQueries(["getAllPlaygroundsDates"])
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "dark",
      });
    }
  })

  const {
    handleSubmit,
    register,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const formSubmit = (data) => {
    addNewTiming.mutate(data)
    // console.log(data);
  };
  const convertToDayName = (date) => {
    var daysNames = ['الأحد', 'الأثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    var d = new Date(date);
    var dayName = daysNames[d.getDay()];
    return dayName
  }

  const addNewPlaygroundTiming = event => {
    setPlaygroundTimingList(playgroundTimingList.concat(
      <div className="flex items-center justify-center gap-1.5 flex-wrap lg:gap-5" key={playgroundTimingList.length}>
        <div className="flex flex-col relative">
          <span className="mb-3 inline-block text-xs sm:text-sm tracking-wide text-slate-600">وقت البداية</span>
          <input type="time" name={`start_time_${playgroundTimingList.length}`} className="border border-slate-400 rounded-lg p-3 bg-white" onChange={handleStartTime} />
          <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">

          </span>
        </div>
        <div className="flex flex-col relative">
          <span className="mb-3 inline-block text-xs sm:text-sm tracking-wide text-slate-600">وقت النهاية</span>
          <input type="time" name={`end_time_${playgroundTimingList.length}`} className="border border-slate-400 rounded-lg p-3 bg-white" onChange={handleEndTime} />
          <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">

          </span>
        </div>
        <div className="flex flex-col relative">
          <span className="mb-3 inline-block text-xs sm:text-sm tracking-wide text-slate-600">قيمة الحجز</span>
          <input type="text" name={`time_value_${playgroundTimingList.length}`} className="border border-slate-400 rounded-lg p-3 bg-white w-32" onChange={handleValueOfTime} />
          <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">

          </span>
        </div>
      </div>
    ))
  }
  if (isLoading) return (<Loader />)
  if (timesLoading) return (<Loader />)
  if (isError) return (<ErrorComponent />)
  // for (var key in PlaygroundTimes?.data) {
  //   console.log(key + " -> " + PlaygroundTimes?.data[key]);
  // }
  // Object.entries(PlaygroundTimes?.data)?.map((item, index) => console.log(item))

  return (
    <>
      <>
        {/* <div className="flex items-center justify-between">
          <div className="text-xl text-slate-950">
            قم بإختيار الملعب اولاً لإظهار الأوقات الخاصة به
          </div>
          <select className="select select-bordered w-full max-w-xs" onChange={(e) => setSelectedPlayground(e.target.value)}>
            <option disabled selected>إختر الملعب</option>
            {data?.data?.data?.map(playground => (
              <option key={playground?.id} value={playground?.id}>{playground?.ar_title}</option>
            ))}
          </select>

        </div> */}
        <div className="flex items-center justify-between flex-col lg:flex-row gap-1.5 w-full mt-10">
          <div className="text-xl text-slate-950">
            قم بإضافة اوقات
          </div>
          <select onChange={(e) => setDays(e.target.value)} className="select select-bordered w-full max-w-xs">
            <option disabled selected>عدد الأيام التي يتم عرضها</option>
            <option value={5}>5</option>
            <option value={10}>10</option>
            <option value={30}>30</option>
          </select>
          <label htmlFor="addNewCategory" className="cursor-pointer btn bg-[#1a5d0d] text-slate-100 hover:bg-slate-700 duration-500" >
            إضافة جديد
          </label>
          <input type="checkbox" id="addNewCategory" className="modal-toggle" />
          <div className="modal">
            <div className="modal-box w-11/12 max-w-4xl">
              <form className="text-center px-5 py-10" onSubmit={handleSubmit(formSubmit)}>
                <h3 className="font-bold text-lg">إضافة توقيت للملعب!</h3>
                <div className="flex mt-10 items-center gap-5">
                  <h3 className="font-bold text-base">في البداية قم بإختيار الملعب!</h3>
                  <select className="select select-bordered w-full max-w-xs" {...register('playground_id')}>
                    <option disabled selected>إختر الملعب</option>
                    {data?.data?.data?.map(playground => (
                      <option key={playground?.id} value={playground?.id}>{playground?.ar_title}</option>
                    ))}
                  </select>
                </div>
                <div className="flex mt-5 items-center gap-8">
                  <h3 className="font-bold text-base">لنقم بتحديد اليوم المناسب!</h3>
                  <div className="" dir="ltr">
                    <Datepicker
                      useRange={false}
                      asSingle={true}
                      value={value}
                      onChange={handleValueChange}
                      inputClassName="relative transition-all duration-300 py-2.5 pl-4 pr-14 w-full border border-gray-300 rounded-lg tracking-wide font-light text-sm placeholder-gray-400 bg-white focus:ring disabled:opacity-40 disabled:cursor-not-allowed focus:border-blue-500 focus:ring-blue-500/20"
                    />
                  </div>
                </div>
                <div className="flex flex-col my-10 items-center gap-5">
                  <h3 className="font-bold text-base text-center">لنقم بتحديد أوقات اللعب!</h3>
                  {/* <div className="flex items-center justify-center gap-5">
                    <div className="flex flex-col relative">
                      <span className="mb-3 inline-block text-xs sm:text-sm tracking-wide text-slate-600">وقت البداية</span>
                      <input type="time" className="border border-slate-400 rounded-lg p-3" {...register('from_time')} />
                      <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">

                      </span>
                    </div>
                    <div className="flex flex-col relative">
                      <span className="mb-3 inline-block text-xs sm:text-sm tracking-wide text-slate-600">وقت النهاية</span>
                      <input type="time" className="border border-slate-400 rounded-lg p-3" {...register('to_time')} />
                      <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">

                      </span>
                    </div>
                  </div> */}
                  {playgroundTimingList}
                  <button type="button" className="border border-slate-300 p-2 rounded-md" onClick={addNewPlaygroundTiming}>إضافة وقت +</button>
                </div>
                <button
                  type="submit"
                  onClick={() => { setNumberOfDays(90) }}
                  disabled={addNewTiming.isLoading}
                  className='btn bg-[#147700] text-slate-50 hover:bg-slate-700 mx-1.5'
                >
                  إضافة
                </button>
                {/* <button
                  type="submit"
                  onClick={() => { setNumberOfDays(10) }}
                  disabled={addNewTiming.isLoading}
                  className='btn bg-[#147700] text-slate-50 hover:bg-slate-700 mx-1.5'
                >
                  إضافة 10 أيام
                </button>
                <button
                  type="submit"
                  onClick={() => { setNumberOfDays(30) }}
                  disabled={addNewTiming.isLoading}
                  className='btn bg-[#147700] text-slate-50 hover:bg-slate-700 mx-1.5'
                >
                  إضافة 30 يوم
                </button> */}
              </form>
              <label htmlFor="addNewCategory" id='closePlayCenterForm' className="btn btn-sm rounded-full absolute top-2 left-2">X</label>
            </div>
          </div>
        </div>
      </>

      {
        timesLoading ?
          <Loader />
          :
          // <section className="container mx-auto mt-10 flex flex-col justify-between bg-white rounded-lg">
          //   <div className="flex p-10 flex-col">
          //     <h3 className="text-lg text-slate-800">{PlaygroundTimes?.message}</h3>

          //     <div className="flex flex-col w-full gap-10 mt-10">
          //       {
          //         Object.values(PlaygroundTimes?.data)?.map(singleMonth => (
          //           <details className="collapse bg-base-200 collapse-plus" key={singleMonth?.date}>
          //             <summary className="collapse-title text-xl font-medium">عرض المعلومات الخاصة بشهر {singleMonth[0]?.month} لسنة {singleMonth[0]?.year}</summary>
          //             <div className="collapse-content">
          //               {
          //                 singleMonth?.map((singleReserve, indx) => (
          //                   <div className="flex justify-between items-center mb-5 border rounded-lg border-slate-400 p-5" key={singleReserve?.date + singleReserve?.from_time + indx}>
          //                     <p className="flex gap-2">
          //                       <span>{indx + 1} - </span>
          //                       <span className="font-bold">تاريخ الحجز :</span>
          //                       <span>{singleReserve?.date}</span>
          //                     </p>
          //                     <p className="flex gap-2">
          //                       <span className="font-bold">وقت الحجز :</span>
          //                       <span>{singleReserve?.from_time} الي {singleReserve?.to_time}</span>
          //                     </p>
          //                     <p className="flex gap-2">
          //                       <span className="font-bold">قيمة الحجز :</span>
          //                       <span>{singleReserve?.value} ريال</span>
          //                     </p>
          //                     <button
          //                       disabled={deleteSingleReservationMutation.isLoading}
          //                       onClick={() => deleteSingleReservation(singleReserve?.date)}
          //                       className={`text-red-500 transition-colors duration-200 hover:text-red-700 
          //                       focus:outline-none text-base p-2 rounded-full bg-red-300/70 
          //                       ${deleteSingleReservationMutation.isLoading ? "opacity-25" : ""}`}
          //                     >
          //                       <MdDeleteForever />
          //                     </button>
          //                   </div>
          //                 ))
          //               }
          //             </div>
          //           </details>
          //         ))
          //       }
          //     </div>
          //   </div>
          // </section>
          <div className="container mx-auto mt-10 flex flex-col justify-between bg-white rounded-lg p-5">
            {Object.entries(PlaygroundTimes?.data)?.map((item, index) => (
              <div className="flex flex-col my-5" key={item[0]}>
                <div className="text-xl text-slate-950 flex gap-1.5 py-3">
                  <span className="text-slate-700 font-semibold">اليوم:</span>
                  <span className="text-slate-700 font-semibold">
                    {/* {console.log(item[1][1]?.times[0]?.day_name_ar||item[1][0]?.times[0]?.day_name_ar||item[1][1]?.times[1]?.day_name_ar||item[1][0]?.times[1]?.day_name_ar)} */}
                    {convertToDayName(item[0])}
                    <span className="text-xs mx-0.5">
                      ({item[0]})
                    </span>
                  </span>
                </div>
                <div className="flex flex-col">
                  {item[1]?.map(i => (
                    <div className="flex overflow-x-auto" key={i?.playground?.id}>
                      <div className="text-green-700 font-bold p-5 border border-slate-400 min-w-[200px]">
                        {i?.playground?.title}
                      </div>
                      {
                        i?.times?.length > 0 ?
                          i?.times?.map(singleTime => (
                            singleTime?.is_active == "active" ?
                              <button
                                onClick={() => {
                                  document.getElementById('my_modal_1').showModal();
                                  setplaygroundData({ data: i?.playground, from_time: singleTime?.from_time, to_time: singleTime?.to_time, playground_time_id: singleTime?.id, price: singleTime?.value, date: singleTime?.date });
                                }}
                                className={`text-slate-600 p-5 border border-slate-400 flex items-center gap-2 text-xs w-full bg-green-700/20`}>
                                <span>{singleTime?.from_time}</span>
                                <span>-</span>
                                <span>{singleTime?.to_time}</span>
                              </button>
                              :
                              <button
                                onClick={() => {
                                  document.getElementById('my_modal_2').showModal();
                                  setSelectedTime({ id: singleTime?.id, date: singleTime?.date })
                                }}
                                className={`text-slate-600 p-5 border border-slate-400 flex items-center gap-2 text-xs w-full bg-gray-700/20`}>
                                <span>{singleTime?.from_time}</span>
                                <span>-</span>
                                <span>{singleTime?.to_time}</span>
                              </button>

                          ))
                          :
                          <div className="text-slate-600 p-5 border border-slate-400 w-full">
                            لا توجد مواعيد في هذا الملعب
                          </div>

                      }
                      {
                        i?.times?.length >= 0 &&
                        <button
                          disabled={deleteSingleReservationMutation.isLoading}
                          onClick={() => deleteSingleReservation({ theData: { playGroundId: i?.playground?.id, theDate: i?.times[0] } })}
                          className={`text-red-500 transition-colors duration-200 hover:text-red-700 mx-3.5 w-8 h-8 mt-2.5 
                                focus:outline-none text-base p-2 rounded-full bg-red-300/70 
                                ${deleteSingleReservationMutation.isLoading ? "opacity-25" : ""}`}
                        >
                          <MdDeleteForever />
                        </button>
                      }
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
      }
      <AddNewReserve data={playgroundData} />
      <ShowNewReserve data={orderDetails} />
    </>
  )
}

export default PlaygroundTiming