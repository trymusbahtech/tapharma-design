'use client'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';

import ErrorComponent from '@/components/global/ErrorComponent';
import Loader from '@/components/global/Loader';
import { useEffect, useState } from 'react';

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

import { postData } from '@/utils/DataFetching';
import { GiAmericanFootballPlayer } from 'react-icons/gi';
import Input from '@/components/global/Input';
import { MdDeleteForever } from 'react-icons/md';
import { FiEdit } from 'react-icons/fi';
import Pagination from '@/components/global/Pagination';
import { toast } from 'react-toastify';
import Swal from 'sweetalert2';
import EditPlayCenter from '@/components/EditPlayCenter';

const schema = yup.object({
  name: yup.string().required("برجاء ادخال مركز اللعب"),
});

const PlayCenter = () => {
  const [page, setPage] = useState(1);
  const [editUser, setEditUser] = useState();
  const queryClient = useQueryClient();

  const BaseUrl = process.env.BASE_URL;
  const getAllPlayCenters = async ({ queryKey }) => {
    const [_, page] = queryKey
    const { data } = await axios.get(`${BaseUrl}/all-play-centers?page=${page}`)
    return data
  }
  const { data, isLoading, isError } = useQuery(['getAllPlayCenters', page], getAllPlayCenters)

  const setNewPlayCenter = useMutation({
    mutationFn: (data) => {
      var formdata = new FormData();
      formdata.append('name', data.name);
      return postData('/create-new-play-center', formdata)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
      }
      else {
        toast.success(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        });
        document.getElementById("closePlayCenterForm").click();
        reset({ name: '' })
      }
      queryClient.invalidateQueries(["getAllPlayCenters"])
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "light",
      });
    }
  })

  const {
    handleSubmit,
    register,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const formSubmit = (data) => {
    setNewPlayCenter.mutate(data)
  };


  useEffect(() => {
    reset({ name: '' })
  }, [])

  const deletePlayCenter = (id) => {
    Swal.fire({
      title: 'هل انت متأكد من حذف هذا المركز?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#147700',
      cancelButtonColor: '#d33',
      confirmButtonText: 'حذف',
      cancelButtonText: 'إلغاء'
    }).then((result) => {
      if (result.isConfirmed) {
        deletePlayCenterMutation.mutate(id);
      }
    })
  }

  const deletePlayCenterMutation = useMutation({
    mutationFn: (id) => {
      var formdata = new FormData();
      formdata.append("id", id);
      return postData('/delete-play-center', formdata)
    },
    onSuccess: () => {
      toast.success('تم حذف المركز', {
        position: "top-right",
        autoClose: 300,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "dark",
      });
      queryClient.invalidateQueries(["getAllPlayCenters"])
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "dark",
      });
    }
  })

  if (isLoading) return (<Loader />)
  if (isError) return (<ErrorComponent />)
  return (
    <>
      <div className="flex items-center justify-between flex-col lg:flex-row gap-1.5">
        <h3 className="text-3xl text-slate-500">
          {data?.message}
        </h3>

        <label htmlFor="addNewPlayCenter" className="cursor-pointer btn bg-[#1a5d0d] text-slate-100 hover:bg-slate-700 duration-500" >
          إضافة جديد
        </label>
        <input type="checkbox" id="addNewPlayCenter" className="modal-toggle" />
        <div className="modal">
          <div className="modal-box w-11/12 max-w-4xl">
            <form onSubmit={handleSubmit(formSubmit)}>
              <h3 className="font-bold text-lg">إضافة أدمن جديد!</h3>
              <div className="flex mt-4 gap-6 flex-wrap">
                <div className="w-full lg:w-[calc(50%-12px)]">
                  <Input
                    id="name"
                    label="مركز اللعب"
                    placeholder="مركز اللعب"
                    type="text"
                    name="name"
                    icon={<GiAmericanFootballPlayer />}
                    register={{ ...register("name") }}
                    errorMessage={errors?.name?.message}
                  />
                </div>
              </div>
              <div className="text-center mt-5">
                <button
                  disabled={setNewPlayCenter.isLoading}
                  className='btn bg-[#147700] text-slate-50 hover:bg-slate-700'
                >
                  إضافة
                  {
                    setNewPlayCenter.isLoading &&
                    <div role="status">
                      <svg aria-hidden="true" className="w-6 h-6 mr-2 text-slate-50 animate-spin fill-[#106000]" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor" />
                        <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill" />
                      </svg>
                      <span className="sr-only"></span>
                    </div>
                  }
                </button>
              </div>
            </form>
            <label htmlFor="addNewPlayCenter" id='closePlayCenterForm' className="btn btn-sm rounded-full absolute top-2 left-2">X</label>
          </div>
        </div>
      </div>

      <section className="container mx-auto mt-10 flex flex-col justify-between">
        <div className="-my-2 overflow-x-auto">
          <div className="inline-block min-w-full align-middle">
            <div className="overflow-hidden border border-gray-200">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="py-3.5 px-4 text-sm font-normal text-left rtl:text-right text-gray-500">
                      <div className="flex items-center gap-x-3">
                        <button className="flex items-center gap-x-2">
                          <span>ID</span>

                          <svg className="h-3" viewBox="0 0 10 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M2.13347 0.0999756H2.98516L5.01902 4.79058H3.86226L3.45549 3.79907H1.63772L1.24366 4.79058H0.0996094L2.13347 0.0999756ZM2.54025 1.46012L1.96822 2.92196H3.11227L2.54025 1.46012Z" fill="currentColor" stroke="currentColor" strokeWidth="0.1" />
                            <path d="M0.722656 9.60832L3.09974 6.78633H0.811638V5.87109H4.35819V6.78633L2.01925 9.60832H4.43446V10.5617H0.722656V9.60832Z" fill="currentColor" stroke="currentColor" strokeWidth="0.1" />
                            <path d="M8.45558 7.25664V7.40664H8.60558H9.66065C9.72481 7.40664 9.74667 7.42274 9.75141 7.42691C9.75148 7.42808 9.75146 7.42993 9.75116 7.43262C9.75001 7.44265 9.74458 7.46304 9.72525 7.49314C9.72522 7.4932 9.72518 7.49326 9.72514 7.49332L7.86959 10.3529L7.86924 10.3534C7.83227 10.4109 7.79863 10.418 7.78568 10.418C7.77272 10.418 7.73908 10.4109 7.70211 10.3534L7.70177 10.3529L5.84621 7.49332C5.84617 7.49325 5.84612 7.49318 5.84608 7.49311C5.82677 7.46302 5.82135 7.44264 5.8202 7.43262C5.81989 7.42993 5.81987 7.42808 5.81994 7.42691C5.82469 7.42274 5.84655 7.40664 5.91071 7.40664H6.96578H7.11578V7.25664V0.633865C7.11578 0.42434 7.29014 0.249976 7.49967 0.249976H8.07169C8.28121 0.249976 8.45558 0.42434 8.45558 0.633865V7.25664Z" fill="currentColor" stroke="currentColor" strokeWidth="0.3" />
                          </svg>
                        </button>
                      </div>
                    </th>

                    <th scope="col" className="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500">
                      البيانات الأساسية
                    </th>

                    <th scope="col" className="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500">
                      <span className="">الإجرائات</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {data?.data?.data?.map(((item, index) => (
                    <tr key={item?.id}>
                      {/* The ID OF EACH ELEMENT  */}
                      <td className="px-4 py-4 text-sm font-medium text-gray-700 whitespace-nowrap">
                        <div className="inline-flex items-center gap-x-3">
                          <span>{index + 1}#</span>
                        </div>
                      </td>
                      {/* The ID OF EACH ELEMENT  */}

                      <td className="px-4 py-4 text-sm text-gray-500 whitespace-nowrap">
                        <div className="flex items-center gap-x-2">
                          <img className="object-cover w-8 h-8 rounded-full" src={`${item?.logo ? item?.logo : "/3d-fluency-administrator.png"}`} alt="user-image" />
                          <div>
                            <h2 className="text-sm font-medium text-gray-800 ">{item?.name}</h2>
                            <p className="text-xs font-normal text-gray-600 ">{item?.email}</p>
                          </div>
                        </div>
                      </td>

                      <td className="px-4 py-4 text-sm whitespace-nowrap">
                        <div className="flex items-center gap-x-2">
                          <button
                            disabled={deletePlayCenterMutation.isLoading}
                            onClick={() => deletePlayCenter(item?.id)}
                            className={`text-red-500 transition-colors duration-200 hover:text-red-700 focus:outline-none text-base p-2 rounded-full bg-red-300/70 ${deletePlayCenterMutation.isLoading ? "opacity-25" : ""}`}
                          >
                            <MdDeleteForever />
                          </button>

                          <label onClick={() => setEditUser(item)} htmlFor="my_modal_6" className="cursor-pointer text-green-600 transition-colors duration-200 hover:text-green-800 focus:outline-none text-base p-2 rounded-full bg-green-300/70" >
                            <FiEdit />
                          </label>
                        </div>
                      </td>
                    </tr>
                  )))}

                </tbody>
              </table>
            </div>
          </div>
        </div>

        <Pagination pagination={data?.data?.meta} page={page} setPage={setPage} queryName="getAllPlayCenters" />

        <EditPlayCenter editUser={editUser} />
      </section>
    </>
  )
}

export default PlayCenter

