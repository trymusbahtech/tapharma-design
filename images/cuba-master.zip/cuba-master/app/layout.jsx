import "@/styles/globals.css";
import { Alexandria } from "next/font/google";
import { LayoutProvider } from "@/components/global/LayoutProvider";
import ReactQueryProvider from "./ReactQueryProvider";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const alexandria = Alexandria({ subsets: ["latin"] });

export const metadata = {
  title: "Copa || كوبا",
  description: "Copa Dashboard",
};

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl" className="light">
      <body className={alexandria.className}>
        <ReactQueryProvider>
          <LayoutProvider>
            {children}
          </LayoutProvider>
        </ReactQueryProvider>
        <ToastContainer />
      </body>
    </html>
  );
}
