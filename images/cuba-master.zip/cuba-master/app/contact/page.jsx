'use client';
import ErrorComponent from '@/components/global/ErrorComponent';
import Loader from '@/components/global/Loader';
import Pagination from '@/components/global/Pagination';
import { postData } from '@/utils/DataFetching';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import React, { useState } from 'react';
import { BsCheck } from 'react-icons/bs';
import { FaRegEye } from 'react-icons/fa';
import { MdDeleteForever, MdOutlineClose } from 'react-icons/md';
import { toast } from 'react-toastify';
import Swal from 'sweetalert2';

const page = () => {
  const [page, setPage] = useState(1)
  const [userData, setUserData] = useState([])

  const BaseUrl = process.env.BASE_URL;
  const getAllContacts = async ({ queryKey }) => {
    const [_, page] = queryKey
    const { data } = await axios.get(`${BaseUrl}/all-contacts?page=${page}`)
    return data
  }
  const { data, isLoading, isError } = useQuery(['getAllContacts', page], getAllContacts);

  const queryClient = useQueryClient();

  const setContactMutation = useMutation({
    mutationFn: (id) => {
      var formdata = new FormData();
      formdata.append("id", id);
      return postData('/mark-contact-as-read', formdata)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
      }
      else {
        toast.success(data.message, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "dark",
        });
      }
      queryClient.invalidateQueries(["getAllContacts"])
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "dark",
      });
    }
  })

  const deleteContact = (id) => {
    Swal.fire({
      title: 'هل انت متأكد من حذف هذه الرسالة?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#147700',
      cancelButtonColor: '#d33',
      confirmButtonText: 'حذف',
      cancelButtonText: 'إلغاء'
    }).then((result) => {
      if (result.isConfirmed) {
        deleteContactMutation.mutate(id);
      }
    })
  }

  const deleteContactMutation = useMutation({
    mutationFn: (id) => {
      var formdata = new FormData();
      formdata.append("id", id);
      return postData('/delete-contact', formdata)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
      }
      else {
        toast.success(data.message, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "dark",
        });
      }
      queryClient.invalidateQueries(["getAllContacts"])
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "dark",
      });
    }
  })

  if (isLoading) return (<Loader />)
  if (isError) return (<ErrorComponent />)
  return (
    <div>
      <h3 className="text-xl lg:text-3xl text-slate-500 px-10 lg:px-0">
        {data?.message}
      </h3>

      <section className="container mx-auto mt-10">
        <div className="-my-2 overflow-x-auto">
          <div className="inline-block min-w-full align-middle">
            <div className="border border-gray-200">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500">
                      أسم المستخدم
                    </th>
                    <th scope="col" className="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500">
                      رقم الهاتف
                    </th>

                    <th scope="col" className="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500">
                      الحالة
                    </th>

                    <th scope="col" className="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500">
                      <span className="">الإجرائات</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {data?.data?.data?.map(((item, index) => (
                    <tr key={item?.id}>
                      <td className="px-4 py-4 text-sm text-gray-500 whitespace-nowrap">
                        <div className="flex items-center gap-x-2">
                          <div>
                            <h2 className="text-sm font-medium text-gray-800 ">{item?.name}</h2>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-sm text-gray-500 whitespace-nowrap">
                        <div className="flex items-center gap-x-2">
                          <div dir='ltr'>
                            <h2 className="text-sm font-medium text-gray-800 ">{item?.phone}</h2>
                          </div>
                        </div>
                      </td>


                      <td className="px-4 py-4 text-sm font-medium text-gray-700 whitespace-nowrap">
                        <button
                          disabled={setContactMutation.isLoading}
                          onClick={() => setContactMutation.mutate(item?.id)}
                          className={`cursor-pointer inline-flex items-center px-3 py-1 rounded-full gap-x-2 ${setContactMutation.isLoading ? "opacity-25" : ""} ${item.is_read === "read" ? "text-emerald-500 bg-emerald-100/60" : "text-red-500 bg-red-100/60"}`}>
                          {item.is_read === "read" ?
                            <BsCheck />
                            :
                            <MdOutlineClose />}
                          <h2 className="text-sm font-normal">{item.is_read === "un_read" ? "غير مقروئة" : "مقروئة"}</h2>
                        </button>
                      </td>
                      <td className="px-4 py-4 text-sm whitespace-nowrap">
                        <div className="flex items-center gap-x-2">
                          <label htmlFor="my_modal_6" onClick={() => setUserData(item)} className="cursor-pointer text-green-600 transition-colors duration-200 hover:text-green-800 focus:outline-none text-base p-2 rounded-full bg-green-300/70" >
                            <FaRegEye />
                          </label>
                          <button
                            disabled={deleteContactMutation.isLoading}
                            onClick={() => deleteContact(item?.id)}
                            className={`text-red-500 transition-colors duration-200 hover:text-red-700 focus:outline-none text-base p-2 rounded-full bg-red-300/70 ${deleteContactMutation.isLoading ? "opacity-25" : ""}`}
                          >
                            <MdDeleteForever />
                          </button>
                        </div>
                      </td>
                    </tr>
                  )))}

                </tbody>
              </table>
            </div>
          </div>
        </div>

        <Pagination pagination={data?.data?.meta} page={page} setPage={setPage} />

        <input type="checkbox" id="my_modal_6" className="modal-toggle" />
        <div className="modal">
          <div className="modal-box max-w-4xl flex flex-col gap-5">
            <h3 className='text-slate-950 font-semibold text-xl'>اسم المستخدم : {userData?.name}</h3>
            <h3 className='text-slate-950 font-semibold text-xl'>البريد الإلكتروني : {userData?.email}</h3>
            <h3 className='text-slate-950 font-semibold text-xl'>
              <span className='me-1'> رقم الهاتف :</span>
              <span dir='ltr'>
                {userData?.phone}
              </span>
            </h3>
            <h3 className='text-slate-950 font-semibold text-xl'>عنوان الرسالة : {userData?.subject}</h3>
            <h3 className='text-slate-950 font-semibold text-xl'>
              <span className='me-1'>الرسالة :{userData?.message}</span>
            </h3>

            <label htmlFor="my_modal_6" id='closeEditForm' className="btn btn-sm rounded-full absolute top-2 left-2">X</label>
          </div>
        </div>

      </section>
    </div>
  )
}

export default page