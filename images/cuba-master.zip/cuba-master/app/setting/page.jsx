"use client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect, useState } from "react";

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

import axios from "axios";
import ErrorComponent from "@/components/global/ErrorComponent";
import Loader from "@/components/global/Loader";
import Input from "@/components/global/Input";

import { GoogleMap, Marker, useJsApiLoader } from '@react-google-maps/api';

import { LuLanguages } from "react-icons/lu";
import { MdOutlineAttachEmail, MdOutlineLocalPolice, MdOutlinePrivacyTip } from "react-icons/md";
import { GiNotebook } from "react-icons/gi";
import { BsFillLockFill, BsLink45Deg, BsPhoneFlip, BsSnapchat, BsTelephone, BsWhatsapp } from "react-icons/bs";
import { ImFacebook2, ImLinkedin } from "react-icons/im";
import { TfiAndroid, TfiInstagram, TfiLocationPin, TfiTwitter, TfiYoutube } from "react-icons/tfi";
import { TbBrandTelegram } from "react-icons/tb";
import { BiLogoGooglePlus } from "react-icons/bi";
import { HiOutlineMailOpen } from "react-icons/hi";
import { FaAppStore } from "react-icons/fa";
import { postData } from "@/utils/DataFetching";
import { toast } from "react-toastify";

const schema = yup.object({
  logo: yup.mixed().test(value => {
    return value.length !== 0 ? value.length : true;
  }),
  ar_title: yup.string().required("برجاء ادخال الأسم بالعربية"),
  en_title: yup.string().required("برجاء ادخال الأسم بالإنجليزية"),
  ar_terms_condition_reservation: yup.string().nullable(),
  en_terms_condition_reservation: yup.string().nullable(),
  ar_about_app: yup.string().nullable(),
  en_about_app: yup.string().nullable(),
  ar_terms_condition: yup.string().nullable(),
  en_terms_condition: yup.string().nullable(),
  ar_privacy_policy: yup.string().nullable(),
  en_privacy_policy: yup.string().nullable(),
  facebook: yup.string().nullable(),
  twitter: yup.string().nullable(),
  instagram: yup.string().nullable(),
  linkedin: yup.string().nullable(),
  telegram: yup.string().nullable(),
  youtube: yup.string().nullable(),
  google_plus: yup.string().nullable(),
  snapchat_ghost: yup.string().nullable(),
  whatsapp: yup.string().nullable(),
  address1: yup.string().nullable(),
  address2: yup.string().nullable(),
  latitude: yup.string().nullable(),
  longitude: yup.string().nullable(),
  phone1: yup.string().nullable(),
  phone2: yup.string().nullable(),
  android_app: yup.string().required("برجاء ادخال رابط تطبيق الاندرويد"),
  ios_app: yup.string().required("برجاء ادخال رابط تطبيق الايفون"),
  email1: yup
    .string()
    .required("حقل البريد الإلكتروني مطلوب")
    .email("برجاء إدخال بريد إلكتروني صالح"),
  email2: yup
    .string().nullable(),
  link: yup.string().nullable(),
});

export default function SettingPage() {
  const BaseUrl = process.env.BASE_URL;
  const { data, isLoading, isError } = useQuery({
    queryKey: ['getSettings'],
    queryFn: async () => {
      const { data } = await axios.get(`${BaseUrl}/getSettings`)
      return data
    }
  })
  let DefaultLocation = { lat: 0, lng: 0 };
  isLoading ? "" : DefaultLocation = { lat: + data?.data?.latitude, lng: + data?.data?.longitude }
  const [defaultLocation, setDefaultLocation] = useState(DefaultLocation);
  const [map, setMap] = useState(null)
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: process.env.GOOGLE_API_KEY
  })

  const onLoad = useCallback(function callback(map) {
    // This is just an example of getting and using the map instance!!! don't just blindly copy!
    const bounds = new window.google.maps.LatLngBounds(DefaultLocation);
    map.fitBounds(bounds);

    setMap(map)
  }, [])

  const onUnmount = useCallback(function callback(map) {
    setMap(null)
  }, [])

  const {
    handleSubmit,
    register,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const formSubmit = (data) => {
    updateSettingMutation.mutate(data);
  };

  // adding values to form after api fetch 
  useEffect(() => {
    // you can do async server request and fill up form
    setTimeout(() => {
      reset({
        logo: data?.data?.logo, ar_title: data?.data?.ar_title, en_title: data?.data?.en_title, ar_terms_condition_reservation: data?.data?.ar_terms_condition_reservation,
        en_terms_condition_reservation: data?.data?.en_terms_condition_reservation, ar_about_app: data?.data?.ar_about_app,
        en_about_app: data?.data?.en_about_app, ar_terms_condition: data?.data?.ar_terms_condition,
        en_terms_condition: data?.data?.en_terms_condition, ar_privacy_policy: data?.data?.ar_privacy_policy, en_privacy_policy: data?.data?.en_privacy_policy,
        facebook: data?.data?.facebook, twitter: data?.data?.twitter, instagram: data?.data?.instagram, linkedin: data?.data?.linkedin, telegram: data?.data?.telegram, youtube: data?.data?.youtube,
        google_plus: data?.data?.google_plus, snapchat_ghost: data?.data?.snapchat_ghost, whatsapp: data?.data?.whatsapp, address1: data?.data?.address1, address2: data?.data?.address2,
        latitude: data?.data?.latitude, longitude: data?.data?.longitude, phone1: data?.data?.phone1,
        phone2: data?.data?.phone2, android_app: data?.data?.android_app, ios_app: data?.data?.ios_app, email1: data?.data?.email1, email2: data?.data?.email2, link: data?.data?.link
      });
      setDefaultLocation({ lat: + data?.data?.latitude, lng: + data?.data?.longitude })
    }, 2000);
  }, [data]);

  function handleChangeLocation(e) {
    setDefaultLocation({ lat: e.latLng.lat(), lng: e.latLng.lng() });
    reset({
      latitude: e.latLng.lat(), longitude: e.latLng.lng()
    })
  }
  const queryClient = useQueryClient();
  const updateSettingMutation = useMutation({
    mutationFn: (theData) => {
      console.log(theData.logo);
      console.log(data?.data?.logo);
      var formdata = new FormData();
      if (theData.logo !== data?.data?.logo && theData.logo.length !== 0) {
        formdata.append('logo', theData.logo[0] && theData.logo[0], theData.logo[0] && theData.logo[0].name)
      }
      else {
        "";
      }
      formdata.append('ar_title', theData.ar_title);
      formdata.append('en_title', theData.en_title);
      formdata.append('ar_terms_condition_reservation', theData.ar_terms_condition_reservation == "null" ? "" : theData.ar_terms_condition_reservation);
      formdata.append('en_terms_condition_reservation', theData.en_terms_condition_reservation == "null" ? "" : theData.en_terms_condition_reservation);
      formdata.append('ar_about_app', theData.ar_about_app == "null" ? "" : theData.ar_about_app);
      formdata.append('en_about_app', theData.en_about_app == "null" ? "" : theData.en_about_app);
      formdata.append('ar_terms_condition', theData.ar_terms_condition == "null" ? "" : theData.ar_terms_condition);
      formdata.append('en_terms_condition', theData.en_terms_condition == "null" ? "" : theData.en_terms_condition);
      formdata.append('ar_privacy_policy', theData.ar_privacy_policy == "null" ? "" : theData.ar_privacy_policy);
      formdata.append('en_privacy_policy', theData.en_privacy_policy == "null" ? "" : theData.en_privacy_policy);
      formdata.append('facebook', theData.facebook == "null" ? "" : theData.facebook);
      formdata.append('twitter', theData.twitter == "null" ? "" : theData.twitter);
      formdata.append('instagram', theData.instagram == "null" ? "" : theData.instagram);
      formdata.append('linkedin', theData.linkedin == "null" ? "" : theData.linkedin);
      formdata.append('telegram', theData.telegram == "null" ? "" : theData.telegram);
      formdata.append('youtube', theData.youtube == "null" ? "" : theData.youtube);
      formdata.append('google_plus', theData.google_plus == "null" ? "" : theData.google_plus);
      formdata.append('snapchat_ghost', theData.snapchat_ghost == "null" ? "" : theData.snapchat_ghost);
      formdata.append('whatsapp', theData.whatsapp == "null" ? "" : theData.whatsapp);
      formdata.append('address1', theData.address1 == "null" ? "" : theData.address1);
      formdata.append('address2', theData.address2 == "null" ? "" : theData.address2);
      formdata.append('latitude', theData.latitude == "null" ? "" : theData.latitude);
      formdata.append('longitude', theData.longitude == "null" ? "" : theData.longitude);
      formdata.append('phone1', theData.phone1 == "null" ? "" : theData.phone1);
      formdata.append('phone2', theData.phone2 == "null" ? "" : theData.phone2);
      formdata.append('android_app', theData.android_app);
      formdata.append('ios_app', theData.ios_app);
      formdata.append('email1', theData.email1);
      formdata.append('email2', theData.email2 == "null" ? "" : theData.email2);
      formdata.append('link', theData.link == "null" ? "" : theData.link);
      return postData('/update-settings', formdata)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
      }
      else {
        toast.success('تم تعديل الإعدادات بنجاح', {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        });
        queryClient.invalidateQueries(["getSettings"])
      }
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "light",
      });
    }
  })

  if (isLoading) return (<Loader />)
  if (isError) return (<ErrorComponent />)
  if (data) {
    return (
      <>
        <h3 className="text-slate-800 text-3xl font-semibold px-10 lg:px-0">
          الإعدادات
        </h3>
        <div className="container mx-auto mt-10 flex flex-col justify-between bg-white p-1.5 lg:p-5 rounded-xl">
          <form onSubmit={handleSubmit(formSubmit)}>
            <div className="flex gap-2 flex-wrap my-10">
              <h3 className="w-full text-green-600 text-lg lg:text-2xl mb-3">
                الإعدادت الإفتراضية
              </h3>
              <Input
                className="grow"
                id="ar_title"
                label="الأسم بالعربية"
                placeholder="الأسم بالعربية"
                type="text"
                name="ar_title"
                icon={<LuLanguages />}
                register={{ ...register("ar_title") }}
                errorMessage={errors?.ar_title?.message}
              />
              <Input
                className="grow"
                id="en_title"
                label="الأسم بالإنجليزية"
                placeholder="الأسم بالإنجليزية"
                type="text"
                name="en_title"
                icon={<LuLanguages />}
                register={{ ...register("en_title") }}
                errorMessage={errors?.en_title?.message}
              />
              {/* <Input
                id="ar_terms_condition_reservation"
                label="شروط واحكام الحجز بالعربية"
                placeholder="شروط واحكام الحجز بالعربية"
                type="text"
                name="ar_terms_condition_reservation"
                icon={<MdOutlinePrivacyTip />}
                register={{ ...register("ar_terms_condition_reservation") }}
                errorMessage={errors?.ar_terms_condition_reservation?.message}
              />
              <Input
                id="en_terms_condition_reservation"
                label="شروط واحكام الحجز بالإنجليزية"
                placeholder="شروط واحكام الحجز بالإنجليزية"
                type="text"
                name="en_terms_condition_reservation"
                icon={<MdOutlinePrivacyTip />}
                register={{ ...register("en_terms_condition_reservation") }}
                errorMessage={errors?.en_terms_condition_reservation?.message}
              />
              <Input
                id="ar_about_app"
                label="عن التطبيق"
                placeholder="عن التطبيق"
                type="text"
                name="ar_about_app"
                icon={<GiNotebook />}
                register={{ ...register("ar_about_app") }}
                errorMessage={errors?.ar_about_app?.message}
              />
              <Input
                id="en_about_app"
                label="عن التطبيق بالانجليزية"
                placeholder="عن التطبيق بالإنجليزية"
                type="text"
                name="en_about_app"
                icon={<GiNotebook />}
                register={{ ...register("en_about_app") }}
                errorMessage={errors?.en_about_app?.message}
              />
              <Input
                id="ar_terms_condition"
                label="الشروط والاحكام"
                placeholder="الشروط والاحكام"
                type="text"
                name="ar_terms_condition"
                icon={<MdOutlineLocalPolice />}
                register={{ ...register("ar_terms_condition") }}
                errorMessage={errors?.ar_terms_condition?.message}
              />
              <Input
                id="en_terms_condition"
                label="الشروط والحكام بالانجليزية"
                placeholder="الشروط والحكام بالانجليزية"
                type="text"
                name="en_terms_condition"
                icon={<MdOutlineLocalPolice />}
                register={{ ...register("en_terms_condition") }}
                errorMessage={errors?.en_terms_condition?.message}
              />
              <Input
                id="ar_privacy_policy"
                label="سياسة الخصوصية"
                placeholder="سياسة الخصوصية"
                type="text"
                name="ar_privacy_policy"
                icon={<BsFillLockFill />}
                register={{ ...register("ar_privacy_policy") }}
                errorMessage={errors?.ar_privacy_policy?.message}
              />
              <Input
                id="en_privacy_policy"
                label="سياسة الخصوصية بالإنجليزية"
                placeholder="سياسة الخصوصية بالإنجليزية"
                type="text"
                name="en_privacy_policy"
                icon={<BsFillLockFill />}
                register={{ ...register("en_privacy_policy") }}
                errorMessage={errors?.en_privacy_policy?.message}
              /> */}
              <div className="flex flex-col gap-1">
                <label htmlFor="logo" className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">تغيير الصورة</label>
                <div className="flex items-center gap-1.5 flex-col lg:flex-row">
                  <input {...register('logo')} id="logo" name='logo' type="file" className="file-input file-input-bordered max-w-[300px]" dir="ltr" />
                  <img src={data?.data?.logo} alt="logo" width={50} height={50} />
                </div>
                <span className="absolute -bottom-5 right-0 w-full  text-xs text-red-700 ">{errors?.logo?.message}</span>
              </div>
            </div>

            <div className="flex gap-2 flex-wrap my-10">
              <h3 className="w-full text-green-600 text-lg lg:text-2xl mb-3">
                إعدادات التواصل الإجتماعي
              </h3>
              <Input
                className="grow"
                id="facebook"
                label="لينك فيسبوك"
                placeholder="لينك فيسبوك"
                type="text"
                name="facebook"
                icon={<ImFacebook2 />}
                register={{ ...register("facebook") }}
                errorMessage={errors?.facebook?.message}
              />
              <Input
                className="grow"
                id="twitter"
                label="لينك تويتر"
                placeholder="لينك تويتر"
                type="text"
                name="twitter"
                icon={<TfiTwitter />}
                register={{ ...register("twitter") }}
                errorMessage={errors?.twitter?.message}
              />
              <Input
                className="grow"
                id="instagram"
                label="لينك انستاجرام"
                placeholder="لينك انستاجرام"
                type="text"
                name="instagram"
                icon={<TfiInstagram />}
                register={{ ...register("instagram") }}
                errorMessage={errors?.instagram?.message}
              />
              <Input
                className="grow"
                id="linkedin"
                label="لينك لينكدان"
                placeholder="لينك لينكدان"
                type="text"
                name="linkedin"
                icon={<ImLinkedin />}
                register={{ ...register("linkedin") }}
                errorMessage={errors?.linkedin?.message}
              />
              <Input
                className="grow"
                id="telegram"
                label="لينك تيليجرام"
                placeholder="لينك تيليجرام"
                type="text"
                name="telegram"
                icon={<TbBrandTelegram />}
                register={{ ...register("telegram") }}
                errorMessage={errors?.telegram?.message}
              />
              <Input
                className="grow"
                id="youtube"
                label="لينك يوتيوب"
                placeholder="لينك يوتيوب"
                type="text"
                name="youtube"
                icon={<TfiYoutube />}
                register={{ ...register("youtube") }}
                errorMessage={errors?.youtube?.message}
              />
              <Input
                className="grow"
                id="google_plus"
                label="لينك جوجل بلس"
                placeholder="لينك جوجل بلس"
                type="text"
                name="google_plus"
                icon={<BiLogoGooglePlus />}
                register={{ ...register("google_plus") }}
                errorMessage={errors?.google_plus?.message}
              />
              <Input
                className="grow"
                id="snapchat_ghost"
                label="لينك سناب شات"
                placeholder="لينك سناب شات"
                type="text"
                name="snapchat_ghost"
                icon={<BsSnapchat />}
                register={{ ...register("snapchat_ghost") }}
                errorMessage={errors?.snapchat_ghost?.message}
              />
              <Input
                className="grow"
                id="whatsapp"
                label="لينك واتس اب"
                placeholder="لينك واتس اب"
                type="text"
                name="whatsapp"
                icon={<BsWhatsapp />}
                register={{ ...register("whatsapp") }}
                errorMessage={errors?.whatsapp?.message}
              />
            </div>

            <div className="flex gap-2 flex-wrap my-10">
              <h3 className="w-full text-green-600 text-lg lg:text-2xl mb-3">
                إعدادات الموقع
              </h3>
              <Input
                className="grow"
                id="address1"
                label="العنوان الأول"
                placeholder="العنوان الأول"
                type="text"
                name="address1"
                icon={<TfiLocationPin />}
                register={{ ...register("address1") }}
                errorMessage={errors?.address1?.message}
              />
              <Input
                className="grow"
                id="address2"
                label="العنوان الثاني"
                placeholder="العنوان الثاني"
                type="text"
                name="address2"
                icon={<TfiLocationPin />}
                register={{ ...register("address2") }}
                errorMessage={errors?.address2?.message}
              />
              <Input
                className="grow"
                id="latitude"
                label="latitude"
                placeholder="latitude"
                type="text"
                name="latitude"
                icon={<TfiLocationPin />}
                register={{ ...register("latitude") }}
                errorMessage={errors?.latitude?.message}
              />
              <Input
                className="grow"
                id="longitude"
                label="longitude"
                placeholder="longitude"
                type="text"
                name="longitude"
                icon={<TfiLocationPin />}
                register={{ ...register("longitude") }}
                errorMessage={errors?.longitude?.message}
              />
              {
                isLoaded &&
                <GoogleMap
                  mapContainerStyle={{ width: "100%", height: "350px" }}
                  center={defaultLocation}
                  zoom={7}
                  onLoad={onLoad}
                  onUnmount={onUnmount}
                  onClick={handleChangeLocation}
                >
                  <Marker
                    position={defaultLocation} />
                </GoogleMap>
              }
            </div>

            <div className="flex gap-2 flex-wrap my-10">
              <h3 className="w-full text-green-600 text-lg lg:text-2xl mb-3">
                إعداد طرق التواصل
              </h3>
              <Input
                className="grow"
                id="phone1"
                label="رقم الهاتف الاساسي"
                placeholder="رقم الهاتف الاساسي"
                type="text"
                name="phone1"
                icon={<BsTelephone />}
                register={{ ...register("phone1") }}
                errorMessage={errors?.phone1?.message}
              />
              <Input
                className="grow"
                id="phone2"
                label="رقم الهاتف الثاني"
                placeholder="رقم الهاتف الثاني"
                type="text"
                name="phone2"
                icon={<BsPhoneFlip />}
                register={{ ...register("phone2") }}
                errorMessage={errors?.phone2?.message}
              />
              <Input
                className="grow"
                id="email1"
                label="عنوان البريد الإلكتروني الأساسي"
                placeholder="عنوان البريد الإلكتروني الأساسي"
                type="text"
                name="email1"
                icon={<HiOutlineMailOpen />}
                register={{ ...register("email1") }}
                errorMessage={errors?.email1?.message}
              />
              <Input
                className="grow"
                id="email2"
                label="عنوان البريد الإلكتروني الثانوي"
                placeholder="عنوان البريد الإلكتروني الثانوي"
                type="text"
                name="email2"
                icon={<MdOutlineAttachEmail />}
                register={{ ...register("email2") }}
                errorMessage={errors?.email2?.message}
              />
              <Input
                className="grow"
                id="link"
                label="الرابط"
                placeholder="الرابط"
                type="text"
                name="link"
                icon={<BsLink45Deg />}
                register={{ ...register("link") }}
                errorMessage={errors?.link?.message}
              />
            </div>

            <div className="flex gap-2 flex-wrap my-10">
              <h3 className="w-full text-green-600 text-lg lg:text-2xl mb-3">
                رابط التطبيق
              </h3>
              <Input
                className="grow"
                id="android_app"
                label="رابط تطبيق الاندرويد"
                placeholder="رابط تطبيق الاندرويد"
                type="text"
                name="android_app"
                icon={<TfiAndroid />}
                register={{ ...register("android_app") }}
                errorMessage={errors?.android_app?.message}
              />
              <Input
                className="grow"
                id="ios_app"
                label="رابط تطبيق الايفون"
                placeholder="رابط تطبيق الايفون"
                type="text"
                name="ios_app"
                icon={<FaAppStore />}
                register={{ ...register("ios_app") }}
                errorMessage={errors?.ios_app?.message}
              />
            </div>

            <div className="flex gap-2 flex-wrap my-10">
              <h3 className="w-full text-green-600 text-lg lg:text-2xl mb-3">
                إعدادات أخري
              </h3>
              <div className="w-full flex gap-5 mt-2 flex-wrap">
                <div className="flex flex-col relative flex-1">
                  <label htmlFor="ar_terms_condition_reservation" className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">
                    شروط واحكام الحجز بالعربية
                  </label>
                  <textarea name="ar_terms_condition_reservation" id="ar_terms_condition_reservation" cols="30" className="border border-slate-400 bg-white rounded-lg p-3" rows="10"{...register("ar_terms_condition_reservation")} placeholder="شروط واحكام الحجز بالعربية">

                  </textarea>
                  <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                    {errors?.ar_terms_condition_reservation?.message}
                  </span>
                </div>
                <div className="flex flex-col relative flex-1">
                  <label htmlFor="en_terms_condition_reservation" className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">
                    شروط واحكام الحجز بالإنجليزية
                  </label>
                  <textarea name="en_terms_condition_reservation" id="en_terms_condition_reservation" cols="30" className="border border-slate-400 bg-white rounded-lg p-3" rows="10"{...register("en_terms_condition_reservation")} placeholder="شروط واحكام الحجز بالإنجليزية">

                  </textarea>
                  <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                    {errors?.en_terms_condition_reservation?.message}
                  </span>
                </div>
                <div className="flex flex-col relative flex-1">
                  <label htmlFor="ar_about_app" className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">
                    عن التطبيق بالعربية
                  </label>
                  <textarea name="ar_about_app" id="ar_about_app" cols="30" className="border border-slate-400 bg-white rounded-lg p-3" rows="10"{...register("ar_about_app")} placeholder="عن التطبيق بالعربية">

                  </textarea>
                  <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                    {errors?.ar_about_app?.message}
                  </span>
                </div>
                <div className="flex flex-col relative flex-1">
                  <label htmlFor="en_about_app" className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">
                    عن التطبيق بالإنجليزية
                  </label>
                  <textarea name="en_about_app" id="en_about_app" cols="30" className="border border-slate-400 bg-white rounded-lg p-3" rows="10"{...register("en_about_app")} placeholder="عن التطبيق بالإنجليزية">

                  </textarea>
                  <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                    {errors?.en_about_app?.message}
                  </span>
                </div>
                <div className="flex flex-col relative flex-1">
                  <label htmlFor="ar_terms_condition" className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">
                    الشروط والأحكام بالعربية
                  </label>
                  <textarea name="ar_terms_condition" id="ar_terms_condition" cols="30" className="border border-slate-400 bg-white rounded-lg p-3" rows="10"{...register("ar_terms_condition")} placeholder="الشروط والأحكام بالعربية">

                  </textarea>
                  <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                    {errors?.ar_terms_condition?.message}
                  </span>
                </div>
                <div className="flex flex-col relative flex-1">
                  <label htmlFor="en_terms_condition" className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">
                    الشروط والأحكام بالإنجليزية
                  </label>
                  <textarea name="en_terms_condition" id="en_terms_condition" cols="30" className="border border-slate-400 bg-white rounded-lg p-3" rows="10"{...register("en_terms_condition")} placeholder="الشروط والأحكام بالإنجليزية">

                  </textarea>
                  <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                    {errors?.en_terms_condition?.message}
                  </span>
                </div>
                <div className="flex flex-col relative flex-1">
                  <label htmlFor="ar_privacy_policy" className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">
                    سياسة الخصوصية بالعربية
                  </label>
                  <textarea name="ar_privacy_policy" id="ar_privacy_policy" cols="30" className="border border-slate-400 bg-white rounded-lg p-3" rows="10"{...register("ar_privacy_policy")} placeholder="سياسة الخصوصية بالعربية">

                  </textarea>
                  <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                    {errors?.ar_privacy_policy?.message}
                  </span>
                </div>
                <div className="flex flex-col relative flex-1">
                  <label htmlFor="en_privacy_policy" className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">
                    سياسة الخصوصية بالإنجليزية
                  </label>
                  <textarea name="en_privacy_policy" id="en_privacy_policy" cols="30" className="border border-slate-400 bg-white rounded-lg p-3" rows="10"{...register("en_privacy_policy")} placeholder="سياسة الخصوصية بالإنجليزية">

                  </textarea>
                  <span className="absolute -bottom-4 right-0 w-full  text-xs text-red-700 ">
                    {errors?.en_privacy_policy?.message}
                  </span>
                </div>
              </div>
            </div>

            <button
              disabled={updateSettingMutation.isLoading}
              className="flex items-center justify-center focus:outline-none text-white text-sm sm:text-base bg-[#198754] hover:bg-[#198754bc] rounded py-2 transition duration-150 ease-in float-left w-52"
            >
              حفظ التعديلات
              {
                updateSettingMutation.isLoading &&
                <div role="status">
                  <svg aria-hidden="true" className="w-6 h-6 mr-2 text-slate-50 animate-spin fill-[#106000]" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor" />
                    <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill" />
                  </svg>
                  <span className="sr-only"></span>
                </div>
              }
            </button>
          </form>
        </div>
      </>
    );
  }
}

