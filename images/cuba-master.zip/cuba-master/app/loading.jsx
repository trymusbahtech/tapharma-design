import Loader from "@/components/global/Loader"

const loader = () => {
    return (
        <Loader />
    )
}

export default loader