import { BiFootball } from "react-icons/bi"
import {
  TbHome2, TbSettings, TbBellRinging, TbUsersGroup, TbCategory2,
  TbClock2, TbGitPullRequest, TbUser, TbInbox, TbCurrencyDollarOff
} from "react-icons/tb"
import { MdOutlineAdminPanelSettings } from "react-icons/md"
import { GiAmericanFootballPlayer } from "react-icons/gi"

export const PagesRoutes = [
  {
    id: 1,
    name: "الصفحات",
    data: [
      {
        id: 1,
        name: 'الرئيسية',
        url: '/',
        icon: <TbHome2 className="w-5 h-5" />
      },
      {
        id: 2,
        name: 'الإعدادات',
        url: '/setting',
        icon: <TbSettings className="w-5 h-5" />
      },
    ]
  },
  {
    id: 2,
    name: "الملاعب",
    data: [
      {
        id: 1,
        name: 'تصنيفات الملاعب',
        url: '/categories',
        icon: <TbCategory2 className="w-5 h-5" />
      },
      {
        id: 2,
        name: 'الملاعب',
        url: '/playgrounds',
        icon: <BiFootball className="w-5 h-5" />
      },
      {
        id: 3,
        name: 'مواعيد الملاعب',
        url: '/playground-timing',
        icon: <TbClock2 className="w-5 h-5" />
      },
      {
        id: 4,
        name: 'طلبات الحجز',
        url: '/requests',
        icon: <TbGitPullRequest className="w-5 h-5" />
      },
      {
        id: 5,
        name: 'مراكز اللعب',
        url: '/play-center',
        icon: <GiAmericanFootballPlayer className="w-5 h-5" />
      },
      {
        id: 6,
        name: 'طلبات إرجاع المدفوعات',
        url: '/payment-rollback',
        icon: <TbCurrencyDollarOff className="w-5 h-5" />
      },
    ]
  },
  {
    id: 3,
    name: "المستخدمين",
    data: [
      {
        id: 1,
        name: 'المستخدمين',
        url: '/users',
        icon: <TbUsersGroup className="w-5 h-5" />
      },
      {
        id: 2,
        name: 'الإشعارات',
        url: '/all_notifications',
        icon: <TbBellRinging className="w-5 h-5" />
      },
      // {
      //   id: 3,
      //   name: 'الملف الشخصي',
      //   url: '/profile',
      //   icon: <TbUser className="w-5 h-5" />
      // },
      {
        id: 4,
        name: 'طلبات التواصل',
        url: '/contact',
        icon: <TbInbox className="w-5 h-5" />
      },
      {
        id: 5,
        name: 'الأدمن',
        url: '/admin',
        icon: <MdOutlineAdminPanelSettings className="w-5 h-5" />
      },
    ]
  },
]