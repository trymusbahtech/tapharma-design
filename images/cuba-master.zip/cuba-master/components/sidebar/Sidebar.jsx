'use client'
import Image from "next/image"
import SidebarRoutes from "./SidebarRoutes"
import LogoutButton from "./LogoutButton"
import { useState } from "react"
import { FaBars } from "react-icons/fa"
import { IoClose } from "react-icons/io5";

const Sidebar = () => {
  const [opend, setOpend] = useState(true)
  return (
    <>
      <button onClick={() => setOpend(true)} className={`fixed lg:hidden right-2 top-2 z-50 bg-white p-2 rounded-full text-slate-800`}>
        <FaBars />
      </button>
      <div className={`min-h-screen flex w-72 flex-shrink-0 antialiased bg-gray-50 text-gray-800 fixed lg:relative z-[9999] duration-500 ${opend ? "right-0" : "-right-full lg:right-0"}`}>
        <div className={`fixed z-0 bg-black/40 left-0 right-0 top-0 bottom-0 ${opend ? "block" : "hidden"} lg:hidden`} onClick={() => setOpend(false)} />
        <div className="flex flex-col w-72 bg-white h-screen border-r shadow-xl fixed">
          <div className="flex items-center justify-between lg:justify-center h-28 border-b px-2.5">
            <Image src='copa 1.svg' width={50} height={50} alt="logo" loading="lazy" />
            <button onClick={() => setOpend(false)} className={`lg:hidden bg-white p-2 rounded-full text-slate-800 border border-slate-200`}>
              <IoClose />
            </button>
          </div>
          <div className="overflow-y-auto overflow-x-hidden flex-grow flex justify-between flex-col">
            <ul className="flex flex-col py-4 space-y-1">
              <SidebarRoutes setOpend={setOpend} />
            </ul>
            <LogoutButton setOpend={setOpend} />
          </div>
        </div>
      </div>
    </>
  )
}

export default Sidebar