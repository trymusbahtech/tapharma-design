import { useMutation, useQueryClient } from '@tanstack/react-query';
import React, { useEffect } from 'react'
import { toast } from 'react-toastify';
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import Input from './global/Input';
import { GiAmericanFootballPlayer } from 'react-icons/gi';
import { postData } from '@/utils/DataFetching';

const schema = yup.object({
  name: yup.string().required("برجاء ادخال مركز اللاعب"),
});

const EditPlayCenter = ({ editUser }) => {
  const {
    handleSubmit,
    register,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    reset({ name: editUser?.name, id: editUser?.id })
  }, [editUser])

  const formSubmit = (data) => {
    editPlayCenterMutation.mutate(data)
  }

  // handle api Fetch 
  const queryClient = useQueryClient();

  const editPlayCenterMutation = useMutation({
    mutationFn: (data) => {
      var formdata = new FormData();
      formdata.append('id', data.id);
      formdata.append('name', data.name);
      return postData('/update-play-center', formdata)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
      }
      else {
        toast.success('تم تعديل مركز اللاعب بنجاح', {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        });
        document.getElementById("closeEditForm").click();
      }
      queryClient.invalidateQueries(["getAllPlayCenters"])
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "light",
      });
    }
  })
  return (
    <>
      <input type="checkbox" id="my_modal_6" className="modal-toggle" />
      <div className="modal">
        <div className="modal-box max-w-4xl">
          <h3 className="font-bold text-xl text-center">تعديل بيانات مركز اللاعب</h3>
          <form onSubmit={handleSubmit(formSubmit)}>
            <div className="flex mt-4 gap-6 flex-wrap">
              <div className="w-full lg:w-[calc(50%-12px)]">
                <Input
                  id="adminName"
                  label="مركز اللعب"
                  placeholder="مركز اللعب"
                  type="text"
                  name="name"
                  icon={<GiAmericanFootballPlayer />}
                  register={{ ...register("name") }}
                  errorMessage={errors?.name?.message}
                />
              </div>
            </div>
            <div className="text-center mt-5">
              <button
                disabled={editPlayCenterMutation.isLoading}
                className='btn bg-[#147700] text-slate-50 hover:bg-slate-700'
              >
                تعديل
                {
                  editPlayCenterMutation.isLoading &&
                  <div role="status">
                    <svg aria-hidden="true" className="w-6 h-6 mr-2 text-slate-50 animate-spin fill-[#106000]" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor" />
                      <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill" />
                    </svg>
                    <span className="sr-only"></span>
                  </div>
                }
              </button>
            </div>
          </form>
          <label htmlFor="my_modal_6" id='closeEditForm' className="btn btn-sm rounded-full absolute top-2 left-2">X</label>
        </div>
      </div>
    </>
  )
}

export default EditPlayCenter