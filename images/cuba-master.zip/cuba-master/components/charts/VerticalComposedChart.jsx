'use client'
import {
  ComposedChart,
  Line,
  Area,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';


const data = [
  {
    name: 'ستاد الملك فهد',
    uv: 590,
    pv: 800,
    amt: 1400,
  },
  {
    name: 'ستاد هزاع',
    uv: 868,
    pv: 967,
    amt: 1506,
  },
  {
    name: 'ستاد القاهرة',
    uv: 1397,
    pv: 1098,
    amt: 989,
  },
  {
    name: 'ستاد الجمهورية',
    uv: 1480,
    pv: 1200,
    amt: 1228,
  },
  {
    name: 'ملعب البادينج',
    uv: 1520,
    pv: 1108,
    amt: 1100,
  },
  {
    name: 'الخماسي 2',
    uv: 1400,
    pv: 680,
    amt: 1700,
  },
];

const VerticalComposedChart = ({ orders }) => {
  // let array = { ...orders?.playgroundNames, ...orders?.playgroundOrdersCount }
  var arrayOfObject = orders?.playgroundNames.map(function (value, index) {
    return { name: value, count: orders?.playgroundOrdersCount[index] }
  });
  return (
    <ResponsiveContainer width="100%" height="100%">
      <ComposedChart
        layout="vertical"
        data={arrayOfObject}
      // margin={{
      //   top: 20,
      //   right: 20,
      //   bottom: 20,
      //   left: 40,
      // }}
      >
        <CartesianGrid stroke="#f5f5f5" />
        <XAxis type="number" />
        <YAxis dataKey="name" type="category" scale="auto" />
        <Tooltip />
        <Legend />
        <Area dataKey="count" name='عدد الحجوزات' fill="#aacf8a" stroke="#aacf8a" />
        <Bar dataKey="count" name='عدد الحجوزات' barSize={15} fill="#427931" />
        <Line dataKey="count" name='عدد الحجوزات' stroke="#7eb360" />
      </ComposedChart>
    </ResponsiveContainer>
  )
}

export default VerticalComposedChart