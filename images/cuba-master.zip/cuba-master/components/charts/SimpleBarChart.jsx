'use client';
import { BarChart, Bar, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
const data = [
  {
    name: 'Page A',
    uv: 4000,
  },
  {
    name: 'Page B',
    uv: 3000,
  },
  {
    name: 'Page C',
    uv: 2000,
  },
  {
    name: 'Page D',
    uv: 2780,
  },
  {
    name: 'Page E',
    uv: 1890,
  },
  {
    name: 'Page F',
    uv: 2390,
  },
  {
    name: 'Page G',
    uv: 3490,
  },
];

const SimpleBarChart = ({ price }) => {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={price}
      // margin={{
      //   top: 15,
      //   right: 0,
      //   left: 0,
      //   bottom: 5,
      // }}
      >
        <CartesianGrid strokeDasharray="2 2" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        {/* <Bar dataKey="pv" fill="#8884d8" maxBarSize={15} /> */}
        <Bar dataKey="total_price" name="السعر الأجمالي" fill="#82ca9d" maxBarSize={15} />
      </BarChart>
    </ResponsiveContainer>
  )
}

export default SimpleBarChart