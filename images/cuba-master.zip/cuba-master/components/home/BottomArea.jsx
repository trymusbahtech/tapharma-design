import RadialBarComponent from "../charts/RadialBarComponent";
import SimpleBarChart from "../charts/SimpleBarChart";
import VerticalComposedChart from "../charts/VerticalComposedChart";

const BottomArea = ({ orders, price, users }) => {
    return (
        <div className="grid grid-cols-12 gap-5">
            {/* price chart  */}
            <div className="xl:col-span-8 col-span-12">
                <div className="card">
                    <header className="card-header">
                        <h4 className="card-title">إرادات الملاعب</h4>
                    </header>
                    <div className="card-body p-2.5 lg:p-6 w-full h-[500px]" dir="ltr">
                        <SimpleBarChart price={price} />
                    </div>
                </div>
            </div>
            {/* price chart  */}

            {/* users area  */}
            <div className="xl:col-span-4 col-span-12">
                <div className="card ">
                    <div className="card-header ">
                        <h4 className="card-title">الأكثر مشاركة</h4>
                    </div>
                    <div className="card-body p-2.5 lg:p-6">
                        <div>
                            <ul className="list-item space-y-3 h-full overflow-x-auto max-h-[450px]">
                                {users?.map(user => (
                                    <li className="flex items-center space-x-3 rtl:space-x-reverse border-b border-slate-100  last:border-b-0 pb-3 last:pb-0" key={user?.id}>
                                        <div>
                                            <div className="w-8 h-8 rounded-[100%]">
                                                <img
                                                    src={user?.logo}
                                                    alt="user_image"
                                                    className="w-full h-full rounded-[100%] object-cover"
                                                />
                                            </div>
                                        </div>
                                        <div className="text-start overflow-hidden text-ellipsis whitespace-nowrap max-w-[63%]">
                                            <div className="text-sm text-slate-600  overflow-hidden text-ellipsis whitespace-nowrap">
                                                {user?.name}
                                            </div>
                                        </div>
                                        <div className="flex-1 ltr:text-right rtl:text-left">
                                            <div className="text-sm font-light text-slate-400 ">
                                                {user?.orders_count} حجز
                                            </div>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            {/* users area  */}

            {/* orders chart  */}
            <div className="xl:col-span-8 col-span-12">
                <div className="card">
                    <div className="card-header">
                        <h4 className="card-title">الملاعب الأكثر حجزا</h4>

                    </div>
                    <div className="card-body p-2.5 lg:p-6">
                        <div className="">
                            <div className="">
                                <div className="h-[460px] w-full bg-white" dir="ltr">
                                    <VerticalComposedChart orders={orders} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* orders chart  */}

            {/* <div className="lg:col-span-4 col-span-12">
                <div className="card">
                    <header className="card-header">
                        <h4 className="card-title">نظرة عامة</h4>
                    </header>
                    <div className="card-body p-6 w-[100%] h-[300px]">
                        <RadialBarComponent orders={orders} />
                    </div>
                </div>
            </div> */}
        </div>
    );
};

export default BottomArea;
