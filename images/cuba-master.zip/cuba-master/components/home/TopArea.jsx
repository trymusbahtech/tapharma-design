import ComposedChartWithAxisLabels from "../charts/ComposedChartWithAxisLabels";
import { GiExtraTime, GiLaurelsTrophy, GiMoneyStack } from "react-icons/gi"

const TopArea = ({ playgroundMoney, playgroundCount, reservation }) => {

    return (
        <div className="grid grid-cols-12 gap-5 mb-5 items-center">

            <div className="2xl:col-span-3 xl:col-span-4 col-span-12">
                <div className="bg-gradient-to-br from-cyan-400 to-green-400 p-4 rounded-[6px] relative" >
                    <div className="max-w-[180px]">
                        <div className="text-xl font-medium text-slate-900 mb-2">
                            ملاعب كوبا ........................
                        </div>
                        <p className="text-sm text-slate-800">
                            اينما كنت! لدينا المزيد
                        </p>
                    </div>
                    <div
                        className="absolute top-1/2 -translate-y-1/2 ltr:right-6 rtl:left-6 mt-2 h-12 w-12 bg-white rounded-full text-xs font-medium flex flex-col items-center justify-center"
                    >
                        هنا
                    </div>
                </div>
            </div>

            <div className="2xl:col-span-9 xl:col-span-8 col-span-12">
                <div className="p-4 card">
                    <div className="flex flex-wrap gap-4">
                        {/* <!-- BEGIN: Group Chart2 --> */}
                        <div className="py-[18px] grow px-4 rounded-[6px] bg-[#E5F9FF]">
                            <div className="flex items-center space-x-6 rtl:space-x-reverse">
                                <div className="flex-none w-[48px] h-[48px]">
                                    <ComposedChartWithAxisLabels stroke="#00c3ff" fill="#bcefff" />
                                </div>
                                <div className="flex-1">
                                    <div className="text-slate-800 text-sm mb-1 font-medium" >
                                        إجمالي الإرادات
                                    </div>
                                    <div className="text-slate-900  text-lg font-medium">
                                        {playgroundMoney} ريال
                                    </div>
                                </div>
                                <div className="p-2 rounded-full border-2 border-[#0094c1]">
                                    <GiMoneyStack className="w-10 text-[40px] text-[#0094c1]" />
                                </div>
                            </div>
                        </div>

                        <div className="py-[18px] grow px-4 rounded-[6px] bg-[#FFEDE5]">
                            <div className="flex items-center space-x-6 rtl:space-x-reverse">
                                <div className="flex-none w-[48px] h-[48px]">
                                    <ComposedChartWithAxisLabels stroke="#fc5e1a" fill="#fcc9b3" />
                                </div>
                                <div className="flex-1">
                                    <div className="text-slate-800  text-sm mb-1 font-medium">
                                        إجمالي الحجوزات
                                    </div>
                                    <div className="text-slate-900  text-lg font-medium">
                                        {reservation} حجز
                                    </div>
                                </div>
                                <div className="p-2 rounded-full border-2 border-[#c85c2e]">
                                    <GiExtraTime className="w-10 text-[40px] text-[#c85c2e]" />
                                </div>
                            </div>
                        </div>

                        <div className="py-[18px] grow px-4 rounded-[6px] bg-[#EAE5FF]">
                            <div className="flex items-center space-x-6 rtl:space-x-reverse">
                                <div className="flex-none w-[48px] h-[48px]">
                                    <ComposedChartWithAxisLabels stroke="#8567fb" fill="#b29ffd" />
                                </div>
                                <div className="flex-1">
                                    <div className="text-slate-800 text-sm mb-1 font-medium">
                                        عدد الملاعب
                                    </div>
                                    <div className="text-slate-900  text-lg font-medium">
                                        {playgroundCount} ملاعب
                                    </div>
                                </div>
                                <div className="p-2 rounded-full border-2 border-[#6c4de6]">
                                    <GiLaurelsTrophy className="w-10 text-[40px] text-[#6c4de6]" />
                                </div>
                            </div>
                        </div>

                        {/* <!-- END: Group Chart2 --> */}
                    </div>
                </div>
            </div>
        </div>
    )
}

export default TopArea