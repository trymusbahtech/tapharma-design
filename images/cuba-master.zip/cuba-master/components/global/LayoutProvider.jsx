// Use the client directive for using usePathname hook.
'use client'

// Use usePathname for catching route name.
import { usePathname } from 'next/navigation';
import Sidebar from '../sidebar/Sidebar';
import { Suspense } from 'react';
import Loader from './Loader';

export const LayoutProvider = ({ children }) => {
  const pathname = usePathname();
  return (
    <Suspense fallback={<Loader />}>
      <div className={`Main-App bg-slate-200 ${pathname !== "/login" ? "flex" : ""}`}>
        {pathname !== "/login" && <Sidebar />}
        <main className={`${pathname !== "/login" ? "p-1.5 lg:p-10 flex-1 rounded-2xl overflow-x-hidden min-h-screen" : ""}`}>
          {children}
        </main>
      </div>
    </Suspense>
  )
};