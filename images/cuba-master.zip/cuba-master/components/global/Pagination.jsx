
'use client'
const Pagination = ({ pagination, page, setPage, queryName }) => {

  const pages = []
  for (let i = 1; i <= pagination?.last_page; i++) {
    pages.push(i)
  }

  return (
    <div className="flex items-center justify-between mt-6">
      <button disabled={page == 1 ? true : null}
        onClick={() => { setPage(page - 1) }}
        className={`flex items-center px-5 py-2 text-sm text-gray-700 capitalize transition-colors duration-200 ${page == 1 ? 'bg-gray-100' : 'bg-white'} 
      border rounded-md gap-x-2 hover:bg-gray-100 `}>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5 rtl:-scale-x-100">
          <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 15.75L3 12m0 0l3.75-3.75M3 12h18" />
        </svg>

        <span>
          السابق
        </span>
      </button>

      <div className="items-center hidden md:flex gap-x-3">
        {
          pagination?.current_page - 1 > 1 &&
          <button className={`px-2 py-1 text-sm rounded-md ${pagination?.current_page - 1 > 1 ? "text-blue-500 bg-blue-200/60" : "text-gray-500"}`} onClick={() => { setPage(1) }}>{1}</button>
        }
        {
          pagination?.current_page - 1 != 0 && <button className={`px-2 py-1 text-sm rounded-md ${pagination?.current_page - 1 != 0 ? "text-blue-500 bg-blue-200/60" : "text-gray-500"}`} onClick={() => { setPage(pagination?.current_page - 1) }}>{pagination?.current_page - 1}</button>
        }
        <button className={`px-2 py-1 text-sm rounded-md text-blue-300 bg-blue-200/30 `} disabled={true}>{pagination?.current_page}</button>

        {pagination?.current_page + 1 != pagination?.last_page && pagination?.current_page + 1 <= pagination?.last_page &&
          <button onClick={() => { setPage(pagination?.current_page + 1) }} className={`px-2 py-1 text-sm rounded-md ${pagination?.current_page + 1 != pagination?.last_page && pagination?.current_page + 1 <= pagination?.last_page ? "text-blue-500 bg-blue-200/60" : "text-gray-500"}`}>{pagination?.current_page + 1}</button>
        }
        {pagination?.current_page + 1 <= pagination?.last_page &&
          <button onClick={() => { setPage(pagination?.last_page) }} className={`px-2 py-1 text-sm rounded-md ${pagination?.current_page + 1 <= pagination?.last_page ? "text-blue-500 bg-blue-200/60" : "text-gray-500"}`}>{pagination?.last_page}</button>
        }
      </div>

      <button
        disabled={page == pagination?.last_page ? true : null}
        onClick={() => { setPage(page + 1) }}
        className={`flex items-center px-5 py-2 text-sm text-gray-700 capitalize transition-colors duration-200 ${page == pagination?.last_page ? "bg-gray-100" : "bg-white"}
        border rounded-md gap-x-2 hover:bg-gray-100 `}>
        <span>
          التالي
        </span>

        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5 rtl:-scale-x-100">
          <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 8.25L21 12m0 0l-3.75 3.75M21 12H3" />
        </svg>
      </button>
    </div>
  )
}

export default Pagination