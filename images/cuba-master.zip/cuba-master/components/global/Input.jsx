'use client';

const Input = ({ id, label, placeholder, type, name, icon, register, errorMessage, disabled, className }) => {
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-2 inline-block text-xs sm:text-sm tracking-wide text-slate-600">{label}</label>
      <div className={`relative transition-all duration-300 ${errorMessage && "mb-4"}`}>
        <div className="inline-flex items-center justify-center absolute left-0 top-0 h-full w-10 text-gray-400">
          {icon}
        </div>
        <input
          id={id}
          type={type}
          name={name}
          className="text-sm bg-white placeholder-gray-500 pl-10 pr-4 rounded-lg border border-gray-400 w-full py-3 focus:outline-none focus:border-blue-400"
          placeholder={placeholder}
          disabled={disabled}
          {...register}
        />
        <span className="absolute -bottom-5 right-0 w-full  text-xs text-red-700 ">{errorMessage}</span>
      </div>
    </div>
  )
}

export default Input