import { postData } from '@/utils/DataFetching';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import React, { useState } from 'react'
import { toast } from 'react-toastify';

const AddNewReserve = ({ data }) => {
  const queryClient = useQueryClient();
  const [userName, setUserName] = useState("")
  const [userPhone, setUserPhone] = useState("")

  function changeTimeFormat(start) {
    var hours = Number(start.match(/^(\d+)/)[1]);
    var minutes = Number(start.match(/:(\d+)/)[1]);
    var AMPM = start.match(/\s(.*)$/)[1];
    if (AMPM == "PM" && hours < 12) hours = hours + 12;
    if (AMPM == "AM" && hours == 12) hours = hours - 12;
    var sHours = hours.toString();
    var sMinutes = minutes.toString();
    if (hours < 10) sHours = "0" + sHours;
    if (minutes < 10) sMinutes = "0" + sMinutes;
    return sHours + ":" + sMinutes;
  }

  function diff(start, end) {

    start = start.split(" ");
    start = start[0].split(":");
    end = end.split(" ");
    end = end[0].split(":");


    var startDate = new Date(0, 0, 0, start[0], start[1], 0);
    var endDate = new Date(0, 0, 0, end[0], end[1], 0);
    var diff = endDate.getTime() - startDate.getTime();
    var hours = Math.floor(diff / 1000 / 60 / 60);
    diff -= hours * 1000 * 60 * 60;
    var minutes = Math.floor(diff / 1000 / 60);

    return hours * 60 + minutes;
  }

  const addNewReserveMutation = useMutation({
    mutationFn: (myDate) => {
      var formdata = new FormData();
      formdata.append("playground_id", data?.data?.id);
      formdata.append("playground_time_id", data?.playground_time_id);
      formdata.append("price", data?.price);
      formdata.append("date", data?.date);
      formdata.append("from_time", changeTimeFormat(data?.from_time));
      formdata.append("to_time", changeTimeFormat(data?.to_time));
      formdata.append("price_order", 1);
      formdata.append("time_in_min", diff(data?.from_time, data?.to_time));
      formdata.append("name", userName);
      formdata.append("phone", userPhone);
      return postData('/make-new-order', formdata)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
        setUserName("")
        setUserPhone("")
        document.getElementById('my_modal_1').close();
      }
      else {
        toast.success(data.message, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "dark",
        });
        setUserName("")
        setUserPhone("")
      }
      document.getElementById('my_modal_1').close();
      queryClient.invalidateQueries(["getAllPlaygroundsDates"])
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "dark",
      });
    }
  })
  return (
    <dialog id="my_modal_1" className="modal">
      <div className="modal-box text-center">
        <h3 className="font-bold text-lg">{data?.data?.title}</h3>
        <p className="py-4">{data?.date}</p>
        <p className="flex items-center justify-center gap-2">
          <span>من الساعة {data?.from_time}</span>
          <span>حتي الساعة {data?.to_time}</span>
        </p>
        <p className="py-4">السعر {data?.price} ر.س</p>
        <input className='w-full px-1.5 py-2.5 my-1.5 border border-slate-100 rounded-lg' type="text" value={userName} onChange={(e) => setUserName(e.target.value)} placeholder='إسم المستخدم' />
        <input className='w-full px-1.5 py-2.5 my-1.5 border border-slate-100 rounded-lg' type="number" value={userPhone} onChange={(e) => setUserPhone(e.target.value)} placeholder='هاتف المستخدم' />
        <div className="flex items-center justify-center gap-2.5">
          <button onClick={() => addNewReserveMutation.mutate()} className="btn bg-green-600 hover:bg-green-500 text-white">حجز الموعد</button>
          <form method="dialog">
            <button className="btn">إغلاق</button>
          </form>
        </div>
      </div>
    </dialog>
  )
}

export default AddNewReserve