import { postData } from '@/utils/DataFetching';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import React from 'react'
import { toast } from 'react-toastify';
import Swal from 'sweetalert2';

const ShowNewReserve = ({ data }) => {
  const queryClient = useQueryClient();
  // console.log(data);
  const endOrderWithFine = (id) => {
    document.getElementById("my_modal_2").close();
    Swal.fire({
      title: 'هل انت متأكد من إلغاء هذا الطلب?',
      icon: 'warning',
      showCancelButton: true,
      showDenyButton: true,
      confirmButtonColor: '#147700',
      denyButtonColor: '#a0a0a0',
      cancelButtonColor: '#d33',
      confirmButtonText: 'إلغاء بدون غرامة',
      denyButtonText: 'إلغاء مع غرامة',
      cancelButtonText: 'تراجع'
    }).then((result) => {
      if (result.isConfirmed) {
        let data = {
          id: id,
          fine: "no"
        }
        endOrderWithFineMutation.mutate(data);
      }
      if (result.isDenied) {
        let data = {
          id: id,
          fine: "yes"
        }
        endOrderWithFineMutation.mutate(data);
      }
    })
  }

  const endOrderWithFineMutation = useMutation({
    mutationFn: (data) => {
      var formdata = new FormData();
      formdata.append("order_id", data?.id);
      formdata.append("make_fine", data?.fine);
      return postData('/cancelOrderWithMakeFine', formdata)
    },
    onSuccess: (data) => {
      if (data.status === "error") {
        toast.error(data?.message, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "light",
        })
      }
      else {
        toast.success(data.message, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          rtl: true,
          theme: "dark",
        });
      }
      queryClient.invalidateQueries(["getAllPlaygroundsDates"])
    },
    onError: () => {
      toast.error('عذرا حدث خطأ ما', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        rtl: true,
        theme: "dark",
      });
    }
  })
  return (
    <dialog id="my_modal_2" className="modal">
      <div className="modal-box text-center">
        <h3 className="font-bold text-lg">{data?.data?.playground?.title}</h3>
        <p className="py-4">{data?.data?.playground_time?.date}</p>
        <p className="py-4">{data?.data?.user?.name}</p>
        <p className="flex items-center justify-center gap-2">
          <span>من الساعة {data?.data?.playground_time?.from_time}</span>
          <span>حتي الساعة {data?.data?.playground_time?.to_time}</span>
        </p>
        <p className="py-4">السعر {data?.data?.price} ر.س</p>
        <div className="flex items-center justify-center gap-2.5">
          <button onClick={() => endOrderWithFine(data?.data?.id)} className="btn bg-green-600 hover:bg-green-500 text-white">إلغاء الحجز</button>
          <a target='_blank' href={`https://wa.me/${data?.data?.user?.phone_code}${data?.data?.user?.phone}/?text=مرحبا%20يا%20${data?.data?.user?.name}%0aتم%20تأكيد%20حجزك%20%0aلملعب%20${data?.data?.playground?.title}%20%0aيوم%20${data?.data?.playground_time?.date}%20من%20${data?.data?.playground_time?.from_time}%20حتي%20${data?.data?.playground_time?.to_time}%0aسعر%20الحجز%20${data?.data?.price}%20ريال`}
            className="btn bg-yellow-600 hover:bg-green-500 text-white">مشاركة</a>
          <form method="dialog">
            <button className="btn">إغلاق</button>
          </form>
        </div>
      </div>
    </dialog>
  )
}

export default ShowNewReserve