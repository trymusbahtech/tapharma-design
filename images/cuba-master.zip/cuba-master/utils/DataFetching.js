const BaseUrl = process.env.BASE_URL;

export async function postData(url, data, headers) {
    const res = await fetch(BaseUrl + url, {
        method: 'POST',
        headers: headers,
        body: data,
        redirect: 'follow'
    })
    const result = await res.json();
    return result;
}

export async function fetchData(url) {
    const res = await fetch(BaseUrl + url)
    if (!res.ok) {
        throw new Error('Failed to fetch data');
    }
    return res.json();
}